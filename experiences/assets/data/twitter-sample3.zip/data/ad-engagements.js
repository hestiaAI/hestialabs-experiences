window.YTD.ad_engagements.part0 = [{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[

 {"impressionAttributes":
    {"deviceInfo": {"osType": "Android"},
     "displayLocation": "TimelineHome",
     "promotedTweetInfo":
        {"tweetId": "1381646278988292098",
        "tweetText":
        "#TrustInTransformation: place your trust in a partner who can help you complete the future-forward transformation into a data-driven company. #CustomerCentricTransformation","urls":
        [],"mediaUrls":
        []},
    "advertiserInfo":
    {"advertiserName":
    "PwC Switzerland","screenName":
    "@PwC_Switzerland"},"matchedTargetingCriteria":
    [{"targetingType":
    "Conversation topics","targetingValue":
    "LinkedIn"},{"targetingType":
    "Conversation topics","targetingValue":
    "Marketing"},{"targetingType":
    "Conversation topics","targetingValue":
    "Adobe Marketing Cloud"},{"targetingType":
    "Conversation topics","targetingValue":
    "Digital Transformation"},{"targetingType":
    "Conversation topics","targetingValue":
    "Online Marketing"},{"targetingType":
    "Locations","targetingValue":
    "Switzerland"},{"targetingType":
    "Languages","targetingValue":
    "English"},{"targetingType":
    "Age","targetingValue":
    "35 and up"}],
    "impressionTime":
        "2022-09-15 09:43:20"},"engagementAttributes":
        [{"engagementTime":
        "2022-09-15 09:43:31","engagementType":
        "CardUrlClick"}]},

{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 19:54:45"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 19:54:45","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 19:47:32"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 19:47:32","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382739756556156945","tweetText":
"We're 🔴 LIVE on #LeadingThroughChange with @schuh and how they reimagined their approach to customer loyalty, plus a special conversation and performance with José Andrés and Dave Matthews. Tune in now: https://t.co/Yr4AjZHkE4","urls":
["https://t.co/Yr4AjZHkE4"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Salesforce","screenName":
"@salesforce"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25692533"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25651244"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25701795"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25684078"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25191423"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25393390"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25560779"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25322756"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25787900"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25492271"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25540891"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25442750"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25290269"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25750729"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25276158"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25244229"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Events","targetingValue":
"EDUCAUSE Annual Conference 2020"},{"targetingType":
"Events","targetingValue":
"ODSC West 2020"},{"targetingType":
"Events","targetingValue":
"Gartner IT Symposium/Xpo in Orlando 2020"},{"targetingType":
"Events","targetingValue":
"TechCrunch Disrupt 2020"},{"targetingType":
"Events","targetingValue":
"Open Data Science Conference 2020"},{"targetingType":
"Events","targetingValue":
"SC20"},{"targetingType":
"Events","targetingValue":
"KubeCon   CloudNativeCon North America 2020"},{"targetingType":
"Events","targetingValue":
"Amazon Re:invent 2020"},{"targetingType":
"Events","targetingValue":
"Web Summit 2020"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Times"},{"targetingType":
"Conversation topics","targetingValue":
"Machine learning"},{"targetingType":
"Conversation topics","targetingValue":
"Zoom"},{"targetingType":
"Conversation topics","targetingValue":
"Cloud computing"},{"targetingType":
"Conversation topics","targetingValue":
"IBM"},{"targetingType":
"Conversation topics","targetingValue":
"Slack"},{"targetingType":
"Conversation topics","targetingValue":
"Reuters"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Technology"},{"targetingType":
"Conversation topics","targetingValue":
"Data Privacy and Protection"},{"targetingType":
"Conversation topics","targetingValue":
"SAP"},{"targetingType":
"Conversation topics","targetingValue":
"The Economist"},{"targetingType":
"Conversation topics","targetingValue":
"Entrepreneurship"},{"targetingType":
"Conversation topics","targetingValue":
"Online Marketing"},{"targetingType":
"Conversation topics","targetingValue":
"McKinsey & Company"},{"targetingType":
"Conversation topics","targetingValue":
"Cybersecurity"},{"targetingType":
"Conversation topics","targetingValue":
"Big Data"},{"targetingType":
"Conversation topics","targetingValue":
"Digital Transformation"},{"targetingType":
"Conversation topics","targetingValue":
"Huawei"},{"targetingType":
"Conversation topics","targetingValue":
"Techcrunch"},{"targetingType":
"Conversation topics","targetingValue":
"Wired"},{"targetingType":
"Conversation topics","targetingValue":
"The Wall Street Journal"},{"targetingType":
"Conversation topics","targetingValue":
"LinkedIn"},{"targetingType":
"Conversation topics","targetingValue":
"Oracle"},{"targetingType":
"Conversation topics","targetingValue":
"Adobe Marketing Cloud"},{"targetingType":
"Conversation topics","targetingValue":
"Future of Work"},{"targetingType":
"Conversation topics","targetingValue":
"Remote work"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ReutersBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Davos"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Inc"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FortuneMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Huawei"},{"targetingType":
"Follower look-alikes","targetingValue":
"@YahooFinance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Entrepreneur"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@wef"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Quicktake"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BusinessInsider"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Benioff"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BW"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FT"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Zoom"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CNNBusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@SlackHQ"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FinancialTimes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@HarvardBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@WSJbusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@GuyKawasaki"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MarketWatch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ianbremmer"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 19:47:29"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 19:51:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 19:51:18","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382739756556156945","tweetText":
"We're 🔴 LIVE on #LeadingThroughChange with @schuh and how they reimagined their approach to customer loyalty, plus a special conversation and performance with José Andrés and Dave Matthews. Tune in now: https://t.co/Yr4AjZHkE4","urls":
["https://t.co/Yr4AjZHkE4"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Salesforce","screenName":
"@salesforce"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25692533"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25651244"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25701795"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25684078"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25191423"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25393390"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25560779"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25322756"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25787900"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25492271"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25540891"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25442750"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25290269"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25750729"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25276158"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25244229"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Events","targetingValue":
"EDUCAUSE Annual Conference 2020"},{"targetingType":
"Events","targetingValue":
"ODSC West 2020"},{"targetingType":
"Events","targetingValue":
"Gartner IT Symposium/Xpo in Orlando 2020"},{"targetingType":
"Events","targetingValue":
"TechCrunch Disrupt 2020"},{"targetingType":
"Events","targetingValue":
"Open Data Science Conference 2020"},{"targetingType":
"Events","targetingValue":
"SC20"},{"targetingType":
"Events","targetingValue":
"KubeCon   CloudNativeCon North America 2020"},{"targetingType":
"Events","targetingValue":
"Amazon Re:invent 2020"},{"targetingType":
"Events","targetingValue":
"Web Summit 2020"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ReutersBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Davos"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Inc"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FortuneMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Huawei"},{"targetingType":
"Follower look-alikes","targetingValue":
"@YahooFinance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Entrepreneur"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@wef"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Quicktake"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BusinessInsider"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Benioff"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BW"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FT"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Zoom"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CNNBusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@SlackHQ"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FinancialTimes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@HarvardBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@WSJbusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@GuyKawasaki"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MarketWatch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ianbremmer"},{"targetingType":
"Conversation topics","targetingValue":
"Digital Transformation"},{"targetingType":
"Conversation topics","targetingValue":
"Techcrunch"},{"targetingType":
"Conversation topics","targetingValue":
"The Wall Street Journal"},{"targetingType":
"Conversation topics","targetingValue":
"Reuters"},{"targetingType":
"Conversation topics","targetingValue":
"Slack"},{"targetingType":
"Conversation topics","targetingValue":
"Online Marketing"},{"targetingType":
"Conversation topics","targetingValue":
"SAP"},{"targetingType":
"Conversation topics","targetingValue":
"LinkedIn"},{"targetingType":
"Conversation topics","targetingValue":
"Remote work"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Times"},{"targetingType":
"Conversation topics","targetingValue":
"Oracle"},{"targetingType":
"Conversation topics","targetingValue":
"McKinsey & Company"},{"targetingType":
"Conversation topics","targetingValue":
"Machine learning"},{"targetingType":
"Conversation topics","targetingValue":
"Wired"},{"targetingType":
"Conversation topics","targetingValue":
"Huawei"},{"targetingType":
"Conversation topics","targetingValue":
"Data Privacy and Protection"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Technology"},{"targetingType":
"Conversation topics","targetingValue":
"Adobe Marketing Cloud"},{"targetingType":
"Conversation topics","targetingValue":
"Future of Work"},{"targetingType":
"Conversation topics","targetingValue":
"Cloud computing"},{"targetingType":
"Conversation topics","targetingValue":
"The Economist"},{"targetingType":
"Conversation topics","targetingValue":
"Cybersecurity"},{"targetingType":
"Conversation topics","targetingValue":
"Big Data"},{"targetingType":
"Conversation topics","targetingValue":
"IBM"},{"targetingType":
"Conversation topics","targetingValue":
"Zoom"},{"targetingType":
"Conversation topics","targetingValue":
"Entrepreneurship"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-16 05:32:59"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 05:33:13","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-04-16 05:33:12","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-16 05:33:17","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-16 05:33:10","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 05:33:11","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-16 05:33:16","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-04-16 05:33:13","engagementType":
"VideoContentViewV2"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 21:39:02"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 21:39:02","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382731641941016581","tweetText":
"Hol dir DOPPELTE GTA$ und RP in allen RC-Bandito-Rennen in #GTAOnline.\n\nDer ganze Nervenkitzel von Rennen mit großen Autos, aber ganz ohne Sicherheitsvorkehrungen.\n\nDas Angebot endet am 21. April.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Rockstar Games","screenName":
"@RockstarGames"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"modding"},{"targetingType":
"Keywords","targetingValue":
"#modding"},{"targetingType":
"Keywords","targetingValue":
"modded"},{"targetingType":
"Keywords","targetingValue":
"backward compatible"},{"targetingType":
"List","targetingValue":
"gtao-018-137-gtaops4xb1pc-activeplayers-latamasia_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-018-136-gtaops4xb1pc-activeplayers-eu_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-028-gtaops4xb1pc-lapsedplayers-eu_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-029-gtaops4xb1pc-lapsedplayers-latamasia_18ce54ypdu8"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-04-15 21:40:54"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 21:40:55","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349010721183592452","tweetText":
"Si vous perdez votre iPhone, vous pouvez effacer son contenu à distance pour protéger vos données.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-04-15 21:39:02"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 21:39:08","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 21:39:05","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 21:39:07","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-15 21:41:10","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 21:39:08","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 20:56:52"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:56:53","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1376568582897692674","tweetText":
"$ENJ ⚡️Supercharger⚡️event is now live!\n\n⚡Deposit $CRO and farm #ENJ with 1-click🖱️\n⚡No gas fees, withdraw anytime\n⚡Available on App &amp; Exchange \n\nSign up 👉 https://t.co/J1ESvcWWZI https://t.co/KLeSYB0Ptj","urls":
["https://t.co/J1ESvcWWZI"],"mediaUrls":
["https://t.co/KLeSYB0Ptj"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@cz_binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Cryptocurrencies"},{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:56:52"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:58:02","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 20:57:09","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1380349644408987652","tweetText":
"🔨 These shoes are virtually indestructible, yet comfortable for daily wear 👟\nGet yours here 👉 https://t.co/5VRlQsXth6 https://t.co/cUYZb3NYXz","urls":
["https://t.co/5VRlQsXth6"],"mediaUrls":
["https://t.co/cUYZb3NYXz"]},"advertiserInfo":
{"advertiserName":
"Tc Mart","screenName":
"@tc_mart23"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:07:50"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:10:09","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-15 20:10:10","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-15 20:10:08","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:10:28","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 20:10:14","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-15 20:10:14","engagementType":
"VideoContent6secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 20:07:50"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:07:50","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1378926468512681990","tweetText":
"🏡 Perfect decoration of your house while protecting privacy 🌳\nGET it 👉 https://t.co/eKzoGrNNTb https://t.co/LQo9CTrKm3","urls":
["https://t.co/eKzoGrNNTb"],"mediaUrls":
["https://t.co/LQo9CTrKm3"]},"advertiserInfo":
{"advertiserName":
"Ravity Store","screenName":
"@RavityStore"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:46:36","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-04-15 20:46:11","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-15 20:46:44","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 20:46:09","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:46:23","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-04-15 20:46:15","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-15 20:46:30","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-04-15 20:46:24","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-04-15 20:46:15","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-04-15 20:46:37","engagementType":
"VideoContentPlaybackComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79054","name":
"#EQS","description":
"Time of arrival: Today, 6 p.m."},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:44:13","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1376568582897692674","tweetText":
"$ENJ ⚡️Supercharger⚡️event is now live!\n\n⚡Deposit $CRO and farm #ENJ with 1-click🖱️\n⚡No gas fees, withdraw anytime\n⚡Available on App &amp; Exchange \n\nSign up 👉 https://t.co/J1ESvcWWZI https://t.co/KLeSYB0Ptj","urls":
["https://t.co/J1ESvcWWZI"],"mediaUrls":
["https://t.co/KLeSYB0Ptj"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Cryptocurrencies"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-04-15 20:07:50"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:09:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:09:49","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-15 20:10:09","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382275541412159490","tweetText":
"Faktencheck: die Willkür des Bundesrats beim Klimafonds https://t.co/uysBaA0W4E","urls":
["https://t.co/uysBaA0W4E"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"reclaimthefacts","screenName":
"@reclaimthefacts"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:47:31","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382297856594354176","tweetText":
"From another dimension: discover the most innovative screen that was ever mounted into a Mercedes-Benz. \n\nWatch the digital world premiere on 15 April, 6 p.m. CEST. https://t.co/QNLd1bRtgO https://t.co/3nOpjj0wft","urls":
["https://t.co/QNLd1bRtgO"],"mediaUrls":
["https://t.co/3nOpjj0wft"]},"advertiserInfo":
{"advertiserName":
"Mercedes-Benz","screenName":
"@MercedesBenz"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Keywords","targetingValue":
"#batteries"},{"targetingType":
"Keywords","targetingValue":
"tech"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-04-15 20:07:50"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:08:44","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:08:40","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-04-15 20:08:53","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1375300944183750656","tweetText":
"🤩 Every Piece Is A Cute Animal! \n🧩 It's not just a puzzle 😍 It's art! \nGet it 👉 https://t.co/X1pIE9gsxC https://t.co/YeGcDCAn9i","urls":
["https://t.co/X1pIE9gsxC"],"mediaUrls":
["https://t.co/YeGcDCAn9i"]},"advertiserInfo":
{"advertiserName":
"Pressl Store","screenName":
"@presslstore"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:45:57","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:46:09","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1376568582897692674","tweetText":
"$ENJ ⚡️Supercharger⚡️event is now live!\n\n⚡Deposit $CRO and farm #ENJ with 1-click🖱️\n⚡No gas fees, withdraw anytime\n⚡Available on App &amp; Exchange \n\nSign up 👉 https://t.co/J1ESvcWWZI https://t.co/KLeSYB0Ptj","urls":
["https://t.co/J1ESvcWWZI"],"mediaUrls":
["https://t.co/KLeSYB0Ptj"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Cryptocurrencies"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@cz_binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-04-15 20:13:06"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:13:11","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1376708143556665346","tweetText":
"🚀 An Icon of Science, Now Within Your Reach!\n💎 This periodic table is a great gift for Science lovers! A perfect collection, safely &amp; carefully crafted.\nGet yours now 👉 https://t.co/vePWmZCC4t https://t.co/1rlpjbl9ps","urls":
["https://t.co/vePWmZCC4t"],"mediaUrls":
["https://t.co/1rlpjbl9ps"]},"advertiserInfo":
{"advertiserName":
"Tc Mart","screenName":
"@tc_mart23"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:47:22","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 20:47:16","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-15 20:47:15","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1381712477533171715","tweetText":
"Spring is in the air… and a serious discount is in your basket:\nThe promo’s extended for 48h, so get a surprise 1 month or 1 year for free when you sign up.\nEnjoy 70% off: https://t.co/faqfPP9Oy4 https://t.co/HKc4UJjz1z","urls":
["https://t.co/faqfPP9Oy4"],"mediaUrls":
["https://t.co/HKc4UJjz1z"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@TheHackersNews"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"13 to 54"}],"impressionTime":
"2021-04-15 20:44:12"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:46:44","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-15 20:47:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-15 20:46:44","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-15 20:46:44","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-15 20:46:42","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382739756556156945","tweetText":
"We're 🔴 LIVE on #LeadingThroughChange with @schuh and how they reimagined their approach to customer loyalty, plus a special conversation and performance with José Andrés and Dave Matthews. Tune in now: https://t.co/Yr4AjZHkE4","urls":
["https://t.co/Yr4AjZHkE4"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Salesforce","screenName":
"@salesforce"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@ReutersBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Davos"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Inc"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FortuneMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Huawei"},{"targetingType":
"Follower look-alikes","targetingValue":
"@YahooFinance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Entrepreneur"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@wef"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Quicktake"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BusinessInsider"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Benioff"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BW"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FT"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Zoom"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CNNBusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@SlackHQ"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FinancialTimes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@HarvardBiz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@WSJbusiness"},{"targetingType":
"Follower look-alikes","targetingValue":
"@GuyKawasaki"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MarketWatch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ianbremmer"},{"targetingType":
"Conversation topics","targetingValue":
"IBM"},{"targetingType":
"Conversation topics","targetingValue":
"Slack"},{"targetingType":
"Conversation topics","targetingValue":
"Zoom"},{"targetingType":
"Conversation topics","targetingValue":
"Digital Transformation"},{"targetingType":
"Conversation topics","targetingValue":
"LinkedIn"},{"targetingType":
"Conversation topics","targetingValue":
"Online Marketing"},{"targetingType":
"Conversation topics","targetingValue":
"Techcrunch"},{"targetingType":
"Conversation topics","targetingValue":
"SAP"},{"targetingType":
"Conversation topics","targetingValue":
"Cloud computing"},{"targetingType":
"Conversation topics","targetingValue":
"Data Privacy and Protection"},{"targetingType":
"Conversation topics","targetingValue":
"Cybersecurity"},{"targetingType":
"Conversation topics","targetingValue":
"Entrepreneurship"},{"targetingType":
"Conversation topics","targetingValue":
"The Economist"},{"targetingType":
"Conversation topics","targetingValue":
"Reuters"},{"targetingType":
"Conversation topics","targetingValue":
"Big Data"},{"targetingType":
"Conversation topics","targetingValue":
"Adobe Marketing Cloud"},{"targetingType":
"Conversation topics","targetingValue":
"Future of Work"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Technology"},{"targetingType":
"Conversation topics","targetingValue":
"Machine learning"},{"targetingType":
"Conversation topics","targetingValue":
"Wired"},{"targetingType":
"Conversation topics","targetingValue":
"Remote work"},{"targetingType":
"Conversation topics","targetingValue":
"McKinsey & Company"},{"targetingType":
"Conversation topics","targetingValue":
"Huawei"},{"targetingType":
"Conversation topics","targetingValue":
"Oracle"},{"targetingType":
"Conversation topics","targetingValue":
"The Wall Street Journal"},{"targetingType":
"Conversation topics","targetingValue":
"Financial Times"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25692533"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25651244"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25701795"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25684078"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25191423"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25393390"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25560779"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25322756"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25787900"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25492271"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25540891"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25442750"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25290269"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25750729"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25276158"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25244229"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Events","targetingValue":
"EDUCAUSE Annual Conference 2020"},{"targetingType":
"Events","targetingValue":
"ODSC West 2020"},{"targetingType":
"Events","targetingValue":
"Gartner IT Symposium/Xpo in Orlando 2020"},{"targetingType":
"Events","targetingValue":
"TechCrunch Disrupt 2020"},{"targetingType":
"Events","targetingValue":
"Open Data Science Conference 2020"},{"targetingType":
"Events","targetingValue":
"SC20"},{"targetingType":
"Events","targetingValue":
"KubeCon   CloudNativeCon North America 2020"},{"targetingType":
"Events","targetingValue":
"Amazon Re:invent 2020"},{"targetingType":
"Events","targetingValue":
"Web Summit 2020"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-15 20:56:52"},"engagementAttributes":
[{"engagementTime":
"2021-04-15 20:58:08","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-15 20:58:09","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-15 20:58:10","engagementType":
"VideoContentMrcView"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382357472732614656","tweetText":
"We're super excited following last week’s launch event. Don't worry if you missed it, you can watch the highlights here, including our announcement of the launch of SIX new devices, Lite Earbuds AND HMD mobile. What are you looking forward to getting your hands on? #LoveTrustKeep https://t.co/tGHrVFntDg","urls":
[],"mediaUrls":
["https://t.co/tGHrVFntDg"]},"advertiserInfo":
{"advertiserName":
"Nokia Mobile","screenName":
"@NokiaMobile"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 to 49"}],"impressionTime":
"2021-04-16 12:53:07"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 13:06:16","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 13:06:39","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1382799641318658048","tweetText":
"The final sale's on:\nThis deal’s your last chance to get the 2-year deal with a huge 70% discount.\n\nTake advantage of it now: https://t.co/61NEKU3kTJ https://t.co/m6c4Hy9l8D","urls":
["https://t.co/61NEKU3kTJ"],"mediaUrls":
["https://t.co/m6c4Hy9l8D"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"online security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TheHackersNews"},{"targetingType":
"Age","targetingValue":
"13 to 54"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-16 12:53:07"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 13:05:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 13:06:16","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1381858634087464960","tweetText":
"Avec les AirPods Pro au design personnalisable, le monde devient votre terrain de jeu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Music festivals and concerts"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-04-16 12:53:07"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 13:01:31","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-16 13:01:51","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-16 13:01:30","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1374345110670966792","tweetText":
"#StoryTime | You already take your smartphone with you everywhere, so why not make it an asset? #Dacia’s team have thought of you by imagining “Dacia Media Control”. Smart isn’t it? \nTo learn more: https://t.co/veyVqO2pMm https://t.co/IPCQAr6hF5","urls":
["https://t.co/veyVqO2pMm"],"mediaUrls":
["https://t.co/IPCQAr6hF5"]},"advertiserInfo":
{"advertiserName":
"Renault Group","screenName":
"@renaultgroup"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Graphic design"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"25 to 49"}],"impressionTime":
"2021-04-16 13:14:21"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 13:25:58","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 13:26:22","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1379450868924223489","tweetText":
"RT @Siemens_Schweiz: Great job flexibility is very important to Iwan. What do you appreciate about your employer? #Newnormal #Worklifebalan…","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Siemens","screenName":
"@Siemens"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"Technology"},{"targetingType":
"Keywords","targetingValue":
"tech"},{"targetingType":
"Keywords","targetingValue":
"technology's"},{"targetingType":
"Keywords","targetingValue":
"#technology"},{"targetingType":
"Keywords","targetingValue":
"technologies"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-16 13:25:39"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 13:25:43","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 13:25:53","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1381858634087464960","tweetText":
"Avec les AirPods Pro au design personnalisable, le monde devient votre terrain de jeu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Music festivals and concerts"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-04-16 10:17:07"},"engagementAttributes":
[{"engagementTime":
"2021-04-16 10:17:14","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-04-16 10:17:13","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-16 10:17:13","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-16 10:17:10","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-16 10:17:12","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-16 10:17:17","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-16 10:17:14","engagementType":
"VideoContentViewThreshold"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1381856502454059009","tweetText":
"Avec les AirPods Pro au design personnalisable, le monde devient votre terrain de jeu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784809"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784808"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784807"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 1"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Desktop"}],"impressionTime":
"2021-04-20 20:01:17"},"engagementAttributes":
[{"engagementTime":
"2021-04-20 20:01:39","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-20 20:01:36","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-20 20:02:26","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-20 20:01:42","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-04-20 20:01:40","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-20 20:01:38","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1376568582897692674","tweetText":
"$ENJ ⚡️Supercharger⚡️event is now live!\n\n⚡Deposit $CRO and farm #ENJ with 1-click🖱️\n⚡No gas fees, withdraw anytime\n⚡Available on App &amp; Exchange \n\nSign up 👉 https://t.co/J1ESvcWWZI https://t.co/KLeSYB0Ptj","urls":
["https://t.co/J1ESvcWWZI"],"mediaUrls":
["https://t.co/KLeSYB0Ptj"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@cz_binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Cryptocurrencies"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-04-20 20:53:29"},"engagementAttributes":
[{"engagementTime":
"2021-04-20 20:53:34","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-20 20:54:08","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-20 20:53:37","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1381858246747635715","tweetText":
"Avec les AirPods Pro au design personnalisable, le monde devient votre terrain de jeu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784809"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784808"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25784807"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 1"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-20 18:36:30"},"engagementAttributes":
[{"engagementTime":
"2021-04-20 19:00:58","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1380067945494233091","tweetText":
"Wir zeigen Ihnen in unserem #Webinar am 27. April 2021 zusammen mit @Drees_Sommer Schweiz, wie ein #SmartOffice bestmöglich geplant, gebaut und betrieben wird.\n\nJetzt anmelden ✏️: \nhttps://t.co/rlcM9A8Wmk https://t.co/KOuLBsRvlK","urls":
["https://t.co/rlcM9A8Wmk"],"mediaUrls":
["https://t.co/KOuLBsRvlK"]},"advertiserInfo":
{"advertiserName":
"Siemens Schweiz","screenName":
"@Siemens_Schweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"digital"},{"targetingType":
"Follower look-alikes","targetingValue":
"@NZZ"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-04-20 18:35:54"},"engagementAttributes":
[{"engagementTime":
"2021-04-20 18:36:05","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-20 18:36:09","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-04-20 18:36:18","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-04-20 18:36:36","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-20 18:36:16","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-04-20 18:36:19","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-04-20 18:36:01","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-20 18:36:14","engagementType":
"VideoContentPlayback75"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372158325408796676","tweetText":
"Avec les nouveaux modèles entièrement électriques, nous sommes prêts à nous diriger vers un avenir neutre en CO2.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-04-20 19:29:38"},"engagementAttributes":
[{"engagementTime":
"2021-04-20 19:30:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-20 19:29:48","engagementType":
"VideoContentPlaybackStart"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400091104784097286","tweetText":
"Apple a développé un robot qui désassemble les iPhones.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"global"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-05 20:39:40"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 20:47:52","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-05 20:47:53","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-05 20:47:52","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-05 20:47:41","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 20:47:53","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-05 20:47:52","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 20:47:45","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-05 20:47:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 20:47:45","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372388533822963713","tweetText":
"Over the past 5 years, Bitcoin has outperformed Gold by &gt;156x. Is your portfolio diversified?\n\nBuying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"}],"impressionTime":
"2021-06-05 20:53:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 20:53:53","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 20:59:05","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 20:53:57","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 20:53:51","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 20:59:03","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400090222948409346","tweetText":
"Apple recycle votre smartphone, même si ce n’est pas un iPhone.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"global"},{"targetingType":
"Keywords","targetingValue":
"co2"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-05 22:32:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 00:53:41","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-06 00:53:42","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-06 00:53:41","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-06 00:53:38","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-06 00:53:42","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-06 00:53:49","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 00:53:40","engagementType":
"VideoContentPlayback75"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372383981849751552","tweetText":
"Binance is the world's largest crypto exchange. That means better price stability, less slippage, and faster trades.\n\nWhy trade anywhere else?\n\nGet the app 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-05 22:09:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:41:02","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-05 22:41:00","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-05 22:41:05","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-05 22:41:01","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 22:41:02","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-05 22:41:04","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:40:59","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:41:06","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1384351527393841155","tweetText":
"No More Mosquito And Flies Filled Summers!\n✅ Kills all mosquitos quickly\n✅ Kids-friendly and chemical-free\n✅ LED Bionic Wave \n✅ Noiseless\nGet yours here 👉 https://t.co/YhcpXh1cH4 https://t.co/kh1evltSjo","urls":
["https://t.co/YhcpXh1cH4"],"mediaUrls":
["https://t.co/kh1evltSjo"]},"advertiserInfo":
{"advertiserName":
"Mikeln Shop","screenName":
"@mikelnshop"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-05 22:09:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:44:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:44:29","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1400184224469065730","tweetText":
"Always-on services mean teams are always at the ready. Join us for three days of inspiring sessions and actionable solutions.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PagerDuty","screenName":
"@pagerduty"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"IT engineering"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-06-05 22:28:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:28:57","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1379658690215616512","tweetText":
"🎖 Navy SEAL team combat shorts - Extremely comfortable and excellent durability 👍\n🔥 Give you unlimited possibilities 💪 \nShop Now for 50% Off 👉 https://t.co/juUC4ldvH1 https://t.co/dqWr2HaIFV","urls":
["https://t.co/juUC4ldvH1"],"mediaUrls":
["https://t.co/dqWr2HaIFV"]},"advertiserInfo":
{"advertiserName":
"Iztore Shop","screenName":
"@iztore_co"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-05 22:09:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:43:43","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 22:43:43","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-05 22:43:44","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-05 22:43:56","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-05 22:43:47","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-05 22:43:54","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:43:41","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:44:00","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:43:44","engagementType":
"VideoContentViewV2"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400090222948409346","tweetText":
"Apple recycle votre smartphone, même si ce n’est pas un iPhone.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"global"},{"targetingType":
"Keywords","targetingValue":
"co2"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-05 22:32:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:32:28","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 22:32:29","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:32:30","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:32:26","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1383146402629496837","tweetText":
"Start your #AIOps journey with AI-driven ITOps solutions from IBM.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IBM Cloud","screenName":
"@IBMcloud"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-06-05 22:53:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:54:06","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-05 22:54:07","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-05 22:54:10","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-05 22:54:12","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:54:05","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-05 22:54:04","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:54:07","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-05 22:54:08","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1380349442549719043","tweetText":
"🔨 These shoes are virtually indestructible, yet comfortable for daily wear 👟\nGet yours here 👉 https://t.co/O7kAu4vz4g https://t.co/I8oTqYvZAU","urls":
["https://t.co/O7kAu4vz4g"],"mediaUrls":
["https://t.co/I8oTqYvZAU"]},"advertiserInfo":
{"advertiserName":
"Tc Mart","screenName":
"@tc_mart23"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-05 22:09:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:45:19","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:45:00","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:45:07","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-05 22:45:08","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-05 22:44:53","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1366602458022047745","tweetText":
"Buy $BTC for as little as US$1\n\n§tack §ats on your terms.\nCredit card New users enjoy 0% credit/debit card fees too!\n\nInstall and Get Started Now.\n#Bitcoin #BTC #CRO","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@nokia"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Reddit"},{"targetingType":
"Keywords","targetingValue":
"amc"},{"targetingType":
"Keywords","targetingValue":
"#amc"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-05 22:28:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:28:40","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:28:42","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:28:43","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400091104784097286","tweetText":
"Apple a développé un robot qui désassemble les iPhones.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"co2"},{"targetingType":
"Keywords","targetingValue":
"global"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-05 22:09:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:40:25","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:39:32","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-05 22:39:09","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-05 22:39:08","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:39:32","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-05 22:39:11","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1366602458022047745","tweetText":
"Buy $BTC for as little as US$1\n\n§tack §ats on your terms.\nCredit card New users enjoy 0% credit/debit card fees too!\n\nInstall and Get Started Now.\n#Bitcoin #BTC #CRO","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#amc"},{"targetingType":
"Keywords","targetingValue":
"amc"},{"targetingType":
"Follower look-alikes","targetingValue":
"@nokia"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Reddit"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-05 22:23:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:24:31","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:24:30","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-05 22:28:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:29:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-05 22:29:30","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1372392067733815298","tweetText":
"Bitcoin has grown a lot. But it isn’t as big as the world's biggest companies. How much more could it grow?\n\nBuying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-05 22:23:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-05 22:28:09","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-05 22:27:51","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-05 22:28:13","engagementType":
"VideoSession"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1394282461077647368","tweetText":
"Maigrir et plus 💪. Adopte de bonnes habitudes dès aujourd'hui grâce à l'app gratuite Fastic 💚.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"FASTIC","screenName":
"@fastic"},"matchedTargetingCriteria":
[{"targetingType":
"App Activity","targetingValue":
"Install Fastic: Fasting App & Intermittent Fasting Tracker ANDROID All"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"OS versions","targetingValue":
"Android Pie and above"}],"impressionTime":
"2021-06-06 07:49:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 07:50:20","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-06 07:50:16","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-06 07:50:27","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 07:50:24","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395407067150704642","tweetText":
"Le nouvel iMac. Maintenant disponible. \nAvec la superpuissance de la puce Apple M1. 7 superbes couleurs. Design incroyablement fin. Écran Retina 4.5K de 24 pouces. Du jamais-vu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#laptop"},{"targetingType":
"Keywords","targetingValue":
"apple"},{"targetingType":
"Keywords","targetingValue":
"laptop"},{"targetingType":
"Keywords","targetingValue":
"#apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleSupport"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppStore"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-06 06:56:51"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 07:26:53","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 06:56:59","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-06 06:57:04","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 06:56:55","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399230262953787395","tweetText":
"Everyone hates #CookieBanners. That is why noyb issued the largest waive of up to 10,000 #GDPR complaints to give users a clear yes/no option. \nFind out more: https://t.co/QCeUs9xNFS https://t.co/i8PhPtVfow","urls":
["https://t.co/QCeUs9xNFS"],"mediaUrls":
["https://t.co/i8PhPtVfow"]},"advertiserInfo":
{"advertiserName":
"noyb","screenName":
"@NOYBeu"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting user engager","targetingValue":
"Retargeting user engager: 911167294365192192"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 1"},{"targetingType":
"Followers of a user id","targetingValue":
"@NOYBeu"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-06 17:25:23"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 17:32:41","engagementType":
"Detail"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397298394570309635","tweetText":
"Read Datadog's latest research report for insights and trends from the #serverless landscape👉 https://t.co/DJCCPqRC9f https://t.co/mynnOva32H","urls":
["https://t.co/DJCCPqRC9f"],"mediaUrls":
["https://t.co/mynnOva32H"]},"advertiserInfo":
{"advertiserName":
"Datadog, Inc.","screenName":
"@datadoghq"},"matchedTargetingCriteria":
[{"targetingType":
"Events","targetingValue":
"Amazon Re:invent 2020"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Desktop"}],"impressionTime":
"2021-06-06 12:49:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 12:51:12","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 12:50:55","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-06 12:50:54","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-06 12:50:51","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-06 15:56:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 15:58:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 15:58:28","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-06 15:58:31","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-06 15:58:32","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 15:58:26","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-06 15:58:24","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-06 15:58:30","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395665026170724353","tweetText":
"Le nouvel iMac. Maintenant disponible.\nAvec la superpuissance de la puce Apple M1. 7 superbes couleurs. Design incroyablement fin. Accessoires assortis. Écran Retina 4.5K de 24 pouces. Du jamais-vu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleSupport"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppStore"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-06 15:56:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 15:56:25","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-06 15:56:23","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-06 15:56:27","engagementType":
"VideoSession"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349010721183592452","tweetText":
"Si vous perdez votre iPhone, vous pouvez effacer son contenu à distance pour protéger vos données.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-06 21:22:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 21:22:19","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-06 21:22:21","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-06 21:22:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-06 21:22:17","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-06 21:22:17","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397207751848341505","tweetText":
"Meet Robin, our Marketing Lead for Aluminium.\n\nHear him discuss the importance of green aluminium in supporting a #LowCarbon future and how we're well placed to support this.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Glencore","screenName":
"@Glencore"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"Commodity"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-06 23:59:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 00:00:02","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-07 00:06:44","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 00:00:05","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-07 00:06:24","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397809946360573952","tweetText":
"🔥Trade BTCUSD &amp; ETHUSD perpetuals with up to 100x leverage \n \n⚡Take long or short positions with no expiry date \n⚡Stake #CRO for lower trading fees\n\nLearn More 👇\nhttps://t.co/xVogp1j6YL https://t.co/AWwictJtJG","urls":
["https://t.co/xVogp1j6YL"],"mediaUrls":
["https://t.co/AWwictJtJG"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 24527794"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 1"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-06 23:59:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 00:06:42","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 00:06:51","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 00:06:42","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397207751848341505","tweetText":
"Meet Robin, our Marketing Lead for Aluminium.\n\nHear him discuss the importance of green aluminium in supporting a #LowCarbon future and how we're well placed to support this.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Glencore","screenName":
"@Glencore"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"Commodity"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-06 23:59:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-06 23:59:11","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-06 23:59:16","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-06 23:59:25","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-06 23:59:10","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-06 23:59:51","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-06 23:59:13","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-06 23:59:12","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-06 23:59:13","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-06 23:59:37","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-06 23:59:23","engagementType":
"VideoContentPlayback25"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400091104784097286","tweetText":
"Apple a développé un robot qui désassemble les iPhones.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"préservation"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-07 15:05:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:06:45","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 15:06:45","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400774238299111430","tweetText":
"Un essai routier d’un genre particulier: découvre pendant 24h nos modèles ID entièrement électriques. Besoin d'aller au bureau ou faire du sport? Envie de profiter du trajet avec ta famille et des amis? Teste tes modèles ID préférés selon tes envies et ton humeur.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla - Model 3"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:05:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:08:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 15:08:48","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-07 15:21:41","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:10:30","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1339094888822919169","tweetText":
"Buy gift cards on https://t.co/vCNztABJoG to get cashback💰 up to 10%!\nMore gift cards available — Amazon, eBay, App Store, Google Play, Razer Gold, https://t.co/CGvN0tgNiq and more! #CRO\nGet App and Shop Now!","urls":
["https://t.co/vCNztABJoG","https://t.co/CGvN0tgNiq"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#coinbase"},{"targetingType":
"Keywords","targetingValue":
"coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:05:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:07:40","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 15:07:44","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390016864592535563","tweetText":
"Present around the world. At home in Europe. Join over 4 million customers at Bitstamp.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bitstamp","screenName":
"@Bitstamp"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:21:41"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:24:17","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 15:24:25","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:24:24","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 15:24:24","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390016864592535563","tweetText":
"Present around the world. At home in Europe. Join over 4 million customers at Bitstamp.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bitstamp","screenName":
"@Bitstamp"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-07 15:05:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:08:28","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:08:26","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390016864592535563","tweetText":
"Present around the world. At home in Europe. Join over 4 million customers at Bitstamp.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bitstamp","screenName":
"@Bitstamp"},"matchedTargetingCriteria":
[{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:29:06"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:29:38","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-07 15:29:31","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-07 15:29:35","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-07 15:29:39","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-07 15:29:34","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-07 15:29:28","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 15:29:38","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-07 15:29:37","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-07 15:29:28","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 15:30:21","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:29:32","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 15:29:39","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-07 15:29:38","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1339094888822919169","tweetText":
"Buy gift cards on https://t.co/vCNztABJoG to get cashback💰 up to 10%!\nMore gift cards available — Amazon, eBay, App Store, Google Play, Razer Gold, https://t.co/CGvN0tgNiq and more! #CRO\nGet App and Shop Now!","urls":
["https://t.co/vCNztABJoG","https://t.co/CGvN0tgNiq"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Keywords","targetingValue":
"#coinbase"},{"targetingType":
"Keywords","targetingValue":
"coinbase"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:29:06"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:29:11","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 15:29:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:29:10","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1399324612140404740","tweetText":
"Nous gardons un œil sur le marché pour que vous puissiez vous détendre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PostFinance","screenName":
"@PostFinance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Forbes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@zeitonline"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 15:08:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 15:10:27","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 15:10:22","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349012294236307458","tweetText":
"Sur votre iPhone, les données de Face ID sont chiffrées et protégées.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-07 12:48:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 12:48:31","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 12:48:33","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 12:48:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 12:48:37","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 12:48:41","engagementType":
"VideoContentPlayback75"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390016864592535563","tweetText":
"Present around the world. At home in Europe. Join over 4 million customers at Bitstamp.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bitstamp","screenName":
"@Bitstamp"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-07 17:13:39"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 17:26:46","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 17:26:49","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 17:26:53","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-07 17:30:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 17:26:45","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 17:30:38","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-07 17:26:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 17:26:48","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1347046397124612096","tweetText":
"Here comes Jade Green! 100% rebate for your Netflix and Spotify subscriptions every month with https://t.co/vCNztABJoG Visa Card!\n\nDownload App Now - Reserve Your Metal Card","urls":
["https://t.co/vCNztABJoG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@techreview"},{"targetingType":
"Follower look-alikes","targetingValue":
"@elonmusk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@EU_Commission"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@guardiantech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerkver"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-07 17:16:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 17:31:46","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 17:31:45","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1339094888822919169","tweetText":
"Buy gift cards on https://t.co/vCNztABJoG to get cashback💰 up to 10%!\nMore gift cards available — Amazon, eBay, App Store, Google Play, Razer Gold, https://t.co/CGvN0tgNiq and more! #CRO\nGet App and Shop Now!","urls":
["https://t.co/vCNztABJoG","https://t.co/CGvN0tgNiq"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Keywords","targetingValue":
"coinbase"},{"targetingType":
"Keywords","targetingValue":
"#coinbase"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 17:26:54"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 17:30:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 17:30:44","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-07 17:30:40","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 17:30:44","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-07 17:30:43","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-07 17:30:47","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 17:30:50","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 17:30:43","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1339094888822919169","tweetText":
"Buy gift cards on https://t.co/vCNztABJoG to get cashback💰 up to 10%!\nMore gift cards available — Amazon, eBay, App Store, Google Play, Razer Gold, https://t.co/CGvN0tgNiq and more! #CRO\nGet App and Shop Now!","urls":
["https://t.co/vCNztABJoG","https://t.co/CGvN0tgNiq"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Keywords","targetingValue":
"coinbase"},{"targetingType":
"Keywords","targetingValue":
"#coinbase"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-07 17:20:13"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 17:31:30","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-07 17:31:36","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 17:31:30","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-07 17:31:31","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-07 17:31:31","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-07 17:31:27","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 17:31:27","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401660172116840456","tweetText":
"Nos spécialistes vous accompagnent tout au long du processus de planification de votre succession avec des solutions sur mesure. En savoir plus.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bank CIC","screenName":
"@Bank_CIC"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-07 06:54:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 06:55:48","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 06:55:50","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1372392067733815298","tweetText":
"Bitcoin has grown a lot. But it isn’t as big as the world's biggest companies. How much more could it grow?\n\nBuying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BTCTN"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-07 06:40:05"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 06:40:29","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 06:40:30","engagementType":
"VideoSession"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1399324612140404740","tweetText":
"Nous gardons un œil sur le marché pour que vous puissiez vous détendre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PostFinance","screenName":
"@PostFinance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Forbes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@zeitonline"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-07 18:51:51"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:52:00","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 18:52:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 18:52:03","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 18:52:04","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401898495267704839","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 18:05:40"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:06:02","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 18:06:06","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 18:14:38","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 18:06:51","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 18:06:10","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1401909309462749193","tweetText":
"$TSLV - listing on June 9th on the TSX.V","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Tier One Silver","screenName":
"@TierOneSilver"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-07 18:51:51"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:52:09","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 18:52:07","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 18:52:08","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1397554200654008321","tweetText":
"Nous prenons chaque jour nos propres décisions. Et c’est bien ainsi.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Erfrischungsgetränke","screenName":
"@info_IGEG"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-07 18:50:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:50:11","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-07 18:50:32","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-07 18:50:33","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-07 18:50:29","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 18:50:26","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-07 18:50:49","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 18:50:20","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 18:50:38","engagementType":
"VideoContentPlayback75"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1314152660166082562","tweetText":
"Here comes Royal Indigo! 100% rebate for your Netflix and Spotify subscriptions every month. Download app now - Reserve your Metal Card","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"coinbase"},{"targetingType":
"Keywords","targetingValue":
"#coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 18:55:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:56:03","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-07 18:55:58","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-07 18:56:00","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-07 18:56:01","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-07 18:56:14","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-07 18:56:03","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-07 18:56:00","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-07 18:56:02","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-07 18:56:02","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-07 18:56:02","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-07 18:55:56","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1400374940025634816","tweetText":
"Wir suchen Verstärkung mehr unter: https://t.co/B92aMmAAcw https://t.co/MvYv44Kodu","urls":
["https://t.co/B92aMmAAcw"],"mediaUrls":
["https://t.co/MvYv44Kodu"]},"advertiserInfo":
{"advertiserName":
"Klinik SGM Langenthal","screenName":
"@KlinikSgm"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-07 18:50:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:51:41","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1389881645621186562","tweetText":
"From a Culture of Innovation to how to Drive Intelligence from Data, join us to 'Rethink Possible'.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Amazon Web Services","screenName":
"@awscloud"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@tagesschau"},{"targetingType":
"Follower look-alikes","targetingValue":
"@SZ"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"35 to 54"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-07 18:50:08"},"engagementAttributes":
[{"engagementTime":
"2021-06-07 18:56:15","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401846479199875073","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-08 05:26:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 05:26:45","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 05:26:41","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 05:26:47","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-08 05:26:42","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-08 05:26:43","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-08 05:26:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 05:26:44","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-08 05:26:44","engagementType":
"VideoContentViewV2"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349015199332900872","tweetText":
"L’assemblage final d’un iPhone ne produit aucun déchet en décharge.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 06:55:43"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 06:55:58","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 06:56:03","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 14:34:16"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 14:44:56","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1395036191528034305","tweetText":
"There's more to life, but little more important: UBS retirement advice for complex financial situations.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UBS Schweiz","screenName":
"@UBSschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 26082990"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 4"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"35 to 49"}],"impressionTime":
"2021-06-08 17:59:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:59:24","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 18:02:28","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401846479199875073","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:04:44","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 17:04:41","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1395273117417840641","tweetText":
"There's more to life, but little more important: secure your family; plan your succession.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UBS Schweiz","screenName":
"@UBSschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 26082990"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 4"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"50 and up"}],"impressionTime":
"2021-06-08 17:04:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:04:11","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-08 17:04:13","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 17:04:09","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 17:04:10","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400084548961116165","tweetText":
"L'app Yuh va changer la manière dont les Suisses utilisent leur argent. Découvrez comment! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:05:05","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:05:24","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 17:05:26","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372392067733815298","tweetText":
"Bitcoin has grown a lot. But it isn’t as big as the world's biggest companies. How much more could it grow?\n\nBuying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:05:32","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 17:05:35","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395273117417840641","tweetText":
"There's more to life, but little more important: secure your family; plan your succession.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UBS Schweiz","screenName":
"@UBSschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 26082990"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 4"},{"targetingType":
"Age","targetingValue":
"50 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:04:32","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1367156855395483648","tweetText":
"Tausche dein Gesicht mit dem von Promis! 👥 🔥\nFüge dein Gesicht in Videos und GIFs ein. Verwandle dich in wen du willst 😎\nKreiere lustige REFACE GIFs und Videos mit dir selbst 🔥🔥🔥\nHab Spaß &amp; begeistere deine Freunde 🎉\nDie beste Gesichtstausch-Qualität im App Store⭐⭐⭐⭐⭐","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Reface","screenName":
"@reface_app"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Spider-Man"},{"targetingType":
"Conversation topics","targetingValue":
"Marvel Universe"},{"targetingType":
"App Activity","targetingValue":
"Install Reface: Face Swap Videos IOS 14 Day"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-08 17:04:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 17:05:04","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 17:05:02","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349014829525311490","tweetText":
"Apple recycle votre smartphone, même si ce n’est pas un iPhone.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-08 10:17:40"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 10:18:29","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 10:18:38","engagementType":
"VideoSession"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402265338377641995","tweetText":
"ROLAND GARROS LE SOIR. EN DIRECT ET EN EXCLUSIVITÉ SUR PRIME VIDEO. DÈS MAINTENANT.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#GameOfThrones"},{"targetingType":
"Keywords","targetingValue":
"#Got"},{"targetingType":
"Follower look-alikes","targetingValue":
"@NetflixFR"},{"targetingType":
"Conversation topics","targetingValue":
"Netflix"},{"targetingType":
"Interests","targetingValue":
"Comedy"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 05:38:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 05:44:38","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399659210741194753","tweetText":
"RT @UberFR: Où irez-vous ?\nRetrouvez les endroits qui vous ont tant manqué 😍","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Uber","screenName":
"@Uber"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Starbucks"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || t1"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || t1"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Paris"},{"targetingType":
"Age","targetingValue":
"18 to 54"}],"impressionTime":
"2021-06-09 05:38:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 05:41:02","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402200172260728833","tweetText":
"Le foot, sans le coup de sifflet final. Sur TikTok, le foot c’est non-stop","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TikTok France","screenName":
"@tiktok_France"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@premierleague"},{"targetingType":
"Follower look-alikes","targetingValue":
"@FIFAWorldCup"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BBCSport"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 to 49"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 05:57:39"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 06:04:34","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400511650663485441","tweetText":
"Il est là. Un essentiel d'été revisité. Une coupe décontractée. Une simplicité inégalée. Shoppez-le dès maintenant.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"H&M","screenName":
"@hm"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 to 49"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 05:38:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 05:45:24","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401826268409122820","tweetText":
"On ne sait pas ce que vous avez prévu ce week-end mais sachez qu’on vous réserve #3JoursEnGrand pour célébrer la réouverture de nos restaurants ! https://t.co/Vg2XMEMfwI","urls":
[],"mediaUrls":
["https://t.co/Vg2XMEMfwI"]},"advertiserInfo":
{"advertiserName":
"McDonald's France","screenName":
"@McDonaldsFrance"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Liste exclusion handle McDo (MAJ 210602)"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"13 to 49"}],"impressionTime":
"2021-06-09 05:38:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 05:45:55","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"btc"},{"targetingType":
"Keywords","targetingValue":
"#btc"},{"targetingType":
"Keywords","targetingValue":
"eth"},{"targetingType":
"Keywords","targetingValue":
"btc's"},{"targetingType":
"Keywords","targetingValue":
"ico"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-08 21:33:06"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 23:27:19","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-08 23:27:16","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 23:27:16","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 23:28:00","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948741741989894","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 21:35:44"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:54:33","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1367156855395483648","tweetText":
"Tausche dein Gesicht mit dem von Promis! 👥 🔥\nFüge dein Gesicht in Videos und GIFs ein. Verwandle dich in wen du willst 😎\nKreiere lustige REFACE GIFs und Videos mit dir selbst 🔥🔥🔥\nHab Spaß &amp; begeistere deine Freunde 🎉\nDie beste Gesichtstausch-Qualität im App Store⭐⭐⭐⭐⭐","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Reface","screenName":
"@reface_app"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Marvel Universe"},{"targetingType":
"Conversation topics","targetingValue":
"Spider-Man"},{"targetingType":
"App Activity","targetingValue":
"Install Reface: Face Swap Videos IOS 14 Day"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:25:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:24:59","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395409041589948418","tweetText":
"Le nouvel iMac. Maintenant disponible.\nAvec la superpuissance de la puce Apple M1. 7 superbes couleurs. Design incroyablement fin. Écran Retina 4.5K de 24 pouces. Du jamais-vu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:22:52","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:22:57","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:27:12","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:27:12","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 21:27:11","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400800832334012418","tweetText":
"Your patients with MET altered NSCLC are faced with poorer prognosis. #ASCO21","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Merck Healthcare","screenName":
"@MerckHealthcare"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@TheLancet"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:28:33","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-08 21:28:31","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:28:38","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:28:33","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-08 21:28:36","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402153982202585109","tweetText":
"CoinGeek Zurich - Livestream | Day 1 https://t.co/0I2OjGUVZs","urls":
["https://t.co/0I2OjGUVZs"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"CoinGeek","screenName":
"@RealCoinGeek"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Blockchain"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Google"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerkver"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Desktop"}],"impressionTime":
"2021-06-08 21:35:44"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:39:06","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:54:36","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950401369411590","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 21:35:44"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:55:05","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1318761856723419136","tweetText":
"A new way to pay for your Recurring Buys in the https://t.co/vCNztABJoG App:\n💲 Fiat Wallet ( $EUR, $GBP &amp; $AUD)!\n\nAutomate crypto purchases using fiat wallet, crypto, or credit card \n🗓 weekly, bi-weekly or monthly \n\nGet started now 💰","urls":
["https://t.co/vCNztABJoG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@techreview"},{"targetingType":
"Follower look-alikes","targetingValue":
"@elonmusk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@EU_Commission"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@guardiantech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerkver"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:27:21","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:27:20","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-08 21:27:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:27:18","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372383981849751552","tweetText":
"Binance is the world's largest crypto exchange. That means better price stability, less slippage, and faster trades.\n\nWhy trade anywhere else?\n\nGet the app 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 21:21:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:24:49","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:24:48","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"btc"},{"targetingType":
"Keywords","targetingValue":
"#btc"},{"targetingType":
"Keywords","targetingValue":
"eth"},{"targetingType":
"Keywords","targetingValue":
"btc's"},{"targetingType":
"Keywords","targetingValue":
"ico"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-08 21:33:06"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 00:10:30","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-09 00:10:30","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-09 00:10:30","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-09 00:16:58","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 00:10:28","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-09 00:10:32","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1387808276184715277","tweetText":
"GO MOJO, c'est le rendez-vous du jeu 100% gratuit du groupe @FDJ. Des dizaines d'euros à gagner chaque semaine et déjà 45.000 gagnants en France !\n\nEt si vous les rejoigniez ?","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Go Mojo","screenName":
"@GoMojo7"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Haut-Rhin"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:32:56","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 23:27:16","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 21:32:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 23:27:17","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 23:27:16","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1367156855395483648","tweetText":
"Tausche dein Gesicht mit dem von Promis! 👥 🔥\nFüge dein Gesicht in Videos und GIFs ein. Verwandle dich in wen du willst 😎\nKreiere lustige REFACE GIFs und Videos mit dir selbst 🔥🔥🔥\nHab Spaß &amp; begeistere deine Freunde 🎉\nDie beste Gesichtstausch-Qualität im App Store⭐⭐⭐⭐⭐","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Reface","screenName":
"@reface_app"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Marvel Universe"},{"targetingType":
"Conversation topics","targetingValue":
"Spider-Man"},{"targetingType":
"Keywords","targetingValue":
"sly"},{"targetingType":
"Keywords","targetingValue":
"ai"},{"targetingType":
"App Activity","targetingValue":
"Install Reface: Face Swap Videos IOS 14 Day"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:30:42","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:30:43","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:31:13","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:31:44","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 21:31:44","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 21:31:54","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349037324244496388","tweetText":
"L’assemblage final d’un iPhone ne produit aucun déchet en décharge.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@CNIL"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:28:52","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:28:51","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"btc's"},{"targetingType":
"Keywords","targetingValue":
"ico"},{"targetingType":
"Keywords","targetingValue":
"btc"},{"targetingType":
"Keywords","targetingValue":
"#btc"},{"targetingType":
"Keywords","targetingValue":
"eth"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:29:12","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-08 21:29:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:29:14","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 21:29:10","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1347046397124612096","tweetText":
"Here comes Jade Green! 100% rebate for your Netflix and Spotify subscriptions every month with https://t.co/vCNztABJoG Visa Card!\n\nDownload App Now - Reserve Your Metal Card","urls":
["https://t.co/vCNztABJoG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@techreview"},{"targetingType":
"Follower look-alikes","targetingValue":
"@elonmusk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@EU_Commission"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ForbesTech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@business"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TechCrunch"},{"targetingType":
"Follower look-alikes","targetingValue":
"@guardiantech"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerkver"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-08 20:30:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 21:32:06","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 21:31:55","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1367156855395483648","tweetText":
"Tausche dein Gesicht mit dem von Promis! 👥 🔥\nFüge dein Gesicht in Videos und GIFs ein. Verwandle dich in wen du willst 😎\nKreiere lustige REFACE GIFs und Videos mit dir selbst 🔥🔥🔥\nHab Spaß &amp; begeistere deine Freunde 🎉\nDie beste Gesichtstausch-Qualität im App Store⭐⭐⭐⭐⭐","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Reface","screenName":
"@reface_app"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Spider-Man"},{"targetingType":
"Conversation topics","targetingValue":
"Marvel Universe"},{"targetingType":
"App Activity","targetingValue":
"Install Reface: Face Swap Videos IOS 14 Day"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-08 18:28:09"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 18:30:26","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-08 18:30:32","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-08 21:21:46","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 18:30:28","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 18:30:50","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395273359055802368","tweetText":
"Il y a plus agréable, mais pas plus important: Protégez votre famille et votre succession.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UBS Schweiz","screenName":
"@UBSschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 26082990"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 4"},{"targetingType":
"Age","targetingValue":
"50 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 18:08:27"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 18:08:30","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-08 18:08:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-08 18:08:32","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-08 18:08:28","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397809946360573952","tweetText":
"🔥Trade BTCUSD &amp; ETHUSD perpetuals with up to 100x leverage \n \n⚡Take long or short positions with no expiry date \n⚡Stake #CRO for lower trading fees\n\nLearn More 👇\nhttps://t.co/xVogp1j6YL https://t.co/AWwictJtJG","urls":
["https://t.co/xVogp1j6YL"],"mediaUrls":
["https://t.co/AWwictJtJG"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 24527794"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 1"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-09 00:10:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 00:19:36","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 00:28:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 00:19:37","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 00:19:41","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 00:19:34","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-09 00:10:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 00:19:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 00:19:17","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 00:19:03","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-09 00:19:06","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-09 00:19:04","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-09 00:19:04","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-09 00:19:08","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-09 00:19:08","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 00:19:06","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-09 00:19:06","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-09 00:19:00","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-09 00:19:04","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-09 00:19:08","engagementType":
"VideoContentViewV2"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402149603047268352","tweetText":
"Ils te feront la guerre, mais ils ne te vaincront pas; car je suis avec toi pour te délivrer, dit l`Éternel.🙏 @moise_katumbi @SalomonKalonda","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"colette nzinga","screenName":
"@ColetteNzinga"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"13 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 23:45:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 23:45:15","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1401948741741989894","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-08 23:47:37"},"engagementAttributes":
[{"engagementTime":
"2021-06-08 23:47:54","engagementType":
"ChargeableImpression"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349013672190996485","tweetText":
"En demander plus à l’iPhone pour en demander moins à la planète.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"}],"impressionTime":
"2021-06-09 07:51:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 07:52:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 07:52:22","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400747012069470208","tweetText":
"#agroécologie Après plusieurs mois de concertation &amp; de recherche, McDo 🇫🇷 lance sa 1ère ferme pilote à #ambitionzerocarbone 🚜 https://t.co/ThKIYyxSva","urls":
[],"mediaUrls":
["https://t.co/ThKIYyxSva"]},"advertiserInfo":
{"advertiserName":
"McDonald's France Newsroom","screenName":
"@McDoFr_Newsroom"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"List","targetingValue":
"Liste exclusion handle McDo (MAJ 210603)"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 06:07:17"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 06:07:29","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402526729655177218","tweetText":
"Tsitsipas repart avec la victoire et son ticket pour les demi-finales.\nLa tenante du titre Swiatek toujours en liste sur deux tableaux.\nEt une dernière session de soirée qui opposera Djokovic à Berrettini ce soir.\n\nC'est le dixième épisode du Snap.\n\n#RolandGarros #RGsurPrime https://t.co/xOVdIBhpyz","urls":
[],"mediaUrls":
["https://t.co/xOVdIBhpyz"]},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RafaelNadal"},{"targetingType":
"Follower look-alikes","targetingValue":
"@DjokerNole"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rolandgarros"},{"targetingType":
"Follower look-alikes","targetingValue":
"@andy_murray"},{"targetingType":
"Follower look-alikes","targetingValue":
"@serenawilliams"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerfederer"},{"targetingType":
"Follower look-alikes","targetingValue":
"@espn"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MariaSharapova"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 08:33:02"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 08:34:43","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79208","name":
"#RGsurPrime","description":
"Roland-Garros sur Prime Video"},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"impressionTime":
"2021-06-09 08:33:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 08:33:07","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79208","name":
"#RGsurPrime","description":
"Roland-Garros sur Prime Video"},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"impressionTime":
"2021-06-09 09:25:26"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:25:27","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400098579906281476","tweetText":
"RT @tousuncotefoot: Aux côtés des clubs d’enfance des Bleus et des 67 millions de Français, nous sommes fiers de soutenir l’@equipedefrance…","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crédit Agricole","screenName":
"@CreditAgricole"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@lequipe"},{"targetingType":
"Follower look-alikes","targetingValue":
"@premierleague"},{"targetingType":
"Follower look-alikes","targetingValue":
"@PSG_inside"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KMbappe"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AntoGriezmann"},{"targetingType":
"Age","targetingValue":
"25 to 49"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 09:24:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:25:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 09:25:24","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402536047339204615","tweetText":
"Join the #Huawei Global Cyber Security &amp; Privacy Protection Transparency Center (Dongguan) Grand Opening Ceremony livestream now! https://t.co/avqUy8MaMY","urls":
["https://t.co/avqUy8MaMY"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Huawei","screenName":
"@Huawei"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Business news"},{"targetingType":
"Conversation topics","targetingValue":
"Tech news"},{"targetingType":
"Conversation topics","targetingValue":
"Technology"},{"targetingType":
"List","targetingValue":
"Exclude audience list20210118"},{"targetingType":
"List","targetingValue":
"Exclude audience list"},{"targetingType":
"List","targetingValue":
"Exclude audience list20210218"},{"targetingType":
"Age","targetingValue":
"18 to 49"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 09:24:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:25:06","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-09 09:25:08","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-09 09:25:04","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 09:25:25","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 09:25:08","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-09 09:25:07","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-09 09:25:02","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400788447401418755","tweetText":
"RT @PPouyanne: 🎊 Heureux de célébrer, entouré du Comex, @TotalEnergies avec nos 100.000 collègues à travers le monde et de parcourir ensemb…","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TotalEnergies","screenName":
"@TotalEnergies"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"25 to 54"}],"impressionTime":
"2021-06-09 09:09:02"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:10:19","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399659210414039042","tweetText":
"RT @UberFR: Où irez-vous ?\nRetrouvez les endroits qui vous ont tant manqué 😍","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Uber","screenName":
"@Uber"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Starbucks"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || t1"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || t1"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Locations","targetingValue":
"Paris"}],"impressionTime":
"2021-06-09 09:09:02"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:09:05","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79208","name":
"#RGsurPrime","description":
"Roland-Garros sur Prime Video"},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"impressionTime":
"2021-06-09 09:24:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 09:25:00","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402294669376200717","tweetText":
"A l'occasion de la #JourneeMondialeDelEnvironnement, notre collaborateur, El Houcine El Mesnaoui de la Sustainability Platform, a pris part à la conférence organisée par la faculté polydisciplinaire de Safi sous le thème « Ville durable et #changementclimatique » \n\n#Vertlavenir https://t.co/JmDuJqi5W1","urls":
[],"mediaUrls":
["https://t.co/JmDuJqi5W1"]},"advertiserInfo":
{"advertiserName":
"OCP","screenName":
"@ocpgroup"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"climate"},{"targetingType":
"Keywords","targetingValue":
"#climatechange"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-09 12:03:38"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 12:03:47","engagementType":
"ChargeableImpression"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400107481049804803","tweetText":
"Scotland is committed to reach net zero emissions by 2045 🏴󠁧󠁢󠁳󠁣 We’re creating jobs, planting new woodlands &amp; leading the way on renewable energies 💚 We want to work with others globally to achieve lasting change 💪 #ScotlandIsNow","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Scotland Is Now 🏴󠁧󠁢󠁳󠁣󠁴󠁿","screenName":
"@Scotland"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Locations","targetingValue":
"Belgium"}],"impressionTime":
"2021-06-09 22:08:39"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 22:09:02","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 22:08:51","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 22:08:41","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 22:08:53","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399123830594060292","tweetText":
"L'énergie, c'est la vie. Nous en avons tous besoin et elle est source de progrès. Alors aujourd'hui, pour contribuer au développement durable de la planète face au défi climatique, nous avançons, ensemble vers de nouvelles énergies.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TotalEnergies","screenName":
"@TotalEnergies"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#businessnews"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Belgium"},{"targetingType":
"Age","targetingValue":
"25 to 54"}],"impressionTime":
"2021-06-09 19:10:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 19:10:50","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 19:10:50","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 19:10:59","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400107481049804803","tweetText":
"Scotland is committed to reach net zero emissions by 2045 🏴󠁧󠁢󠁳󠁣 We’re creating jobs, planting new woodlands &amp; leading the way on renewable energies 💚 We want to work with others globally to achieve lasting change 💪 #ScotlandIsNow","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Scotland Is Now 🏴󠁧󠁢󠁳󠁣󠁴󠁿","screenName":
"@Scotland"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Locations","targetingValue":
"Belgium"}],"impressionTime":
"2021-06-09 19:08:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 19:08:36","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-09 19:08:21","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 19:08:50","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-09 19:08:13","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-09 19:08:06","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 19:08:06","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 19:09:03","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-09 19:09:24","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 19:08:21","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-09 19:09:06","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-09 19:08:09","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"Spotlight","promotedTrendInfo":
{"trendId":
"79208","name":
"#RGsurPrime","description":
"Roland-Garros sur Prime Video"},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"impressionTime":
"2021-06-09 20:57:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 20:57:09","engagementType":
"SpotlightView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400109765297065991","tweetText":
"L’Écosse se veut plus juste et plus verte 💚 Nous allons atteindre zéro émission nette d’ici 2045 de façon juste et équitable : c’est inscrit dans la loi 🏴 #ScotlandIsNow","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Scotland Is Now 🏴󠁧󠁢󠁳󠁣󠁴󠁿","screenName":
"@Scotland"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Keywords","targetingValue":
"travelling"},{"targetingType":
"Keywords","targetingValue":
"technologies"},{"targetingType":
"Keywords","targetingValue":
"travel"},{"targetingType":
"Keywords","targetingValue":
"news"},{"targetingType":
"Locations","targetingValue":
"Paris"}],"impressionTime":
"2021-06-09 20:34:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 20:37:49","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399123704647503872","tweetText":
"L'énergie, c'est la vie. Nous en avons tous besoin et elle est source de progrès. Alors aujourd'hui, pour contribuer au développement durable de la planète face au défi climatique, nous avançons, ensemble vers de nouvelles énergies.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TotalEnergies","screenName":
"@TotalEnergies"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Age","targetingValue":
"25 to 54"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-09 20:34:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 20:38:11","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402713748696076288","tweetText":
"H̶o̶m̶e̶r̶u̶n̶ ̶!̶\nPoint, Berrettini.\n\n#RolandGarros #RGsurPrime https://t.co/YGHM85H2wj","urls":
[],"mediaUrls":
["https://t.co/YGHM85H2wj"]},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Netflix"},{"targetingType":
"Follower look-alikes","targetingValue":
"@NetflixFR"},{"targetingType":
"Interests","targetingValue":
"Comedy"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-09 20:34:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 20:35:50","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402634370666672129","tweetText":
"Dans la vie, il y a des sujets qui divisent.\nCe #Thread en fait partie ⬇️\n\nOn écrit :","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"McDonald's France","screenName":
"@McDonaldsFrance"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Liste exclusion handle McDo (MAJ 210602)"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"25 to 49"}],"impressionTime":
"2021-06-09 20:34:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 20:35:16","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399659211076759558","tweetText":
"RT @UberFR: Verre en terrasse, repas de famille, départ en week-end... ☀️ \nEt vous, où irez-vous ?","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Uber","screenName":
"@Uber"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Starbucks"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || t1"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || t1"},{"targetingType":
"Locations","targetingValue":
"Paris"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-10 05:24:52"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 05:25:26","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1392421097031802882","tweetText":
"Development is about way more than just software. 🧑‍💻 Check out our IT colleagues’ experience.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"ING België","screenName":
"@INGBelgie"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Locations","targetingValue":
"Belgium"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"25 to 49"}],"impressionTime":
"2021-06-09 23:02:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 23:06:36","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 23:06:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 23:06:37","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395764469997899778","tweetText":
"Tant de nouvelles histoires, tant d'aventures magiques pour toute la famille. Découvrez Raya et le Dernier Dragon, Luca de Disney et Pixar, et Loki de Marvel Studios sur #DisneyPlus.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"DisneyPlusBE","screenName":
"@DisneyPlusBE"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Belgium"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"13 to 49"}],"impressionTime":
"2021-06-09 23:02:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 23:06:08","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-09 23:06:17","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-09 23:06:08","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-09 23:06:01","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-09 23:05:54","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 23:06:08","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-09 23:06:05","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-09 23:05:57","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 23:06:00","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-09 23:05:56","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-09 23:06:25","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397944828365791239","tweetText":
"Face à la tyrannie, la révolution représente l'espoir. Incarnez Dani Rojas dans sa lutte contre le dictateur Antón Castillo !","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Far Cry 6","screenName":
"@FarCrygame"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Belgium"}],"impressionTime":
"2021-06-09 23:02:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 23:05:34","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-09 23:05:33","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-09 23:05:30","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-09 23:05:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 23:05:24","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-09 23:05:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 23:05:29","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-09 23:05:19","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 23:05:21","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-09 23:05:18","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402592617637060608","tweetText":
"🤑 L'offre se passe de commentaire !","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Pronos Belges","screenName":
"@PronosBelges"},"matchedTargetingCriteria":
[{"targetingType":
"Events","targetingValue":
"MLB Season 2021"},{"targetingType":
"Events","targetingValue":
"NHL Playoffs 2021 "},{"targetingType":
"Events","targetingValue":
"NBA Playoffs 2021"},{"targetingType":
"Events","targetingValue":
"NBA Season 2020-2021"},{"targetingType":
"List","targetingValue":
"REGISTRATION - 15/04"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Belgium"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"}],"impressionTime":
"2021-06-09 23:02:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 23:06:25","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-09 23:06:24","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-09 23:06:38","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-09 23:06:24","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 23:06:24","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399123830594060292","tweetText":
"L'énergie, c'est la vie. Nous en avons tous besoin et elle est source de progrès. Alors aujourd'hui, pour contribuer au développement durable de la planète face au défi climatique, nous avançons, ensemble vers de nouvelles énergies.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TotalEnergies","screenName":
"@TotalEnergies"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Age","targetingValue":
"25 to 54"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Belgium"}],"impressionTime":
"2021-06-09 23:02:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 23:06:44","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-09 23:06:45","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-09 23:07:01","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402627311271297033","tweetText":
"Roland-Garros, ce soir. \nRetrouvez Djokovic face à Berrettini pour la dernière session de soirée en direct et en exclusivité sur Prime Video dès 19h15.\n\n#RGsurPrime","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Amazon Prime Video France","screenName":
"@PrimeVideoFR"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RafaelNadal"},{"targetingType":
"Follower look-alikes","targetingValue":
"@DjokerNole"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rolandgarros"},{"targetingType":
"Follower look-alikes","targetingValue":
"@andy_murray"},{"targetingType":
"Follower look-alikes","targetingValue":
"@serenawilliams"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerfederer"},{"targetingType":
"Follower look-alikes","targetingValue":
"@espn"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MariaSharapova"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-09 18:39:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 18:41:05","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399659210741194753","tweetText":
"RT @UberFR: Où irez-vous ?\nRetrouvez les endroits qui vous ont tant manqué 😍","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Uber","screenName":
"@Uber"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Starbucks"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_HardChurned || ca_exp_4023475274_2502038603 || t1"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || control"},{"targetingType":
"List","targetingValue":
"FRA_DMAs_Rider_SoftChurned || ca_exp_852613882_756219152 || t1"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Locations","targetingValue":
"Paris"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-09 18:39:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-09 18:41:14","engagementType":
"ChargeableImpression"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402652191551377415","tweetText":
"Magnum présente : \"\"Miley in Layers\". Prenez vos écouteurs et écoutez le show exclusif de Miley Cyrus en 8 Dimensions. Disponible dès maintenant.  \n#MileyInLayers #ShowYourLayers #MileyByMagnum","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Magnum France","screenName":
"@Magnum_France"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 11:27:43"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 11:27:46","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 15:13:23"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 15:13:23","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399251799882694656","tweetText":
"iPhone 12 et la #5G d’Orange. Au plus proche des moments qui comptent 📷💬","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Orange France","screenName":
"@Orange_France"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 to 54"}],"impressionTime":
"2021-06-10 15:13:23"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 15:13:25","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402652032545308675","tweetText":
"Magnum présente : \"\"Miley in Layers\". Prenez vos écouteurs et écoutez le show exclusif de Miley Cyrus en 8 Dimensions. Disponible dès maintenant.  \n#MileyInLayers #ShowYourLayers #MileyByMagnum","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Magnum France","screenName":
"@Magnum_France"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 15:36:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 15:37:02","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402230144920698881","tweetText":
"« Suzanne », c’est 64 pages de portraits, d’histoires inédites et d’interviews inspirantes de joueuses de tennis d’hier, d’aujourd’hui et de demain !\nA retrouver en supplément du dernier numéro de Society, dispo chez votre marchand de journaux 🎾 https://t.co/3NsMi2fycR","urls":
[],"mediaUrls":
["https://t.co/3NsMi2fycR"]},"advertiserInfo":
{"advertiserName":
"Mastercard France","screenName":
"@MastercardFR"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@rolandgarros"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Wimbledon"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 15:36:36"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 15:39:22","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"Spotlight","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 15:00:57"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 11:41:31","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 11:41:29","engagementType":
"SpotlightView"},{"engagementTime":
"2021-06-11 11:41:30","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 11:41:33","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402652144419885059","tweetText":
"Magnum présente : \"\"Miley in Layers\". Prenez vos écouteurs et écoutez le show exclusif de Miley Cyrus en 8 Dimensions. Disponible dès maintenant.  \n#MileyInLayers #ShowYourLayers #MileyByMagnum","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Magnum France","screenName":
"@Magnum_France"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 16:44:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 17:00:23","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401796065360240642","tweetText":
"Rendez-vous dans nos boutiques pour jouer ! Vos connaissances sur la série #Lupin de @NetflixFR et sur Orange vous seront utiles 😉","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Orange France","screenName":
"@Orange_France"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Netflix"},{"targetingType":
"Keywords","targetingValue":
"famille"},{"targetingType":
"Follower look-alikes","targetingValue":
"@NetflixFR"},{"targetingType":
"Follower look-alikes","targetingValue":
"@canalplus"},{"targetingType":
"Interests","targetingValue":
"Comedy"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-10 16:33:56"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 16:38:39","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401886666109947908","tweetText":
"Pré-réservez Pokémon Diamant Étincelant et Pokémon Perle Scintillante dès maintenant !\n\nLa génération Pokémon la plus attendue des joueurs arrive le 19 novembre sur Nintendo Switch.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Nintendo France","screenName":
"@NintendoFrance"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"pokemon go"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"13 and up"}],"impressionTime":
"2021-06-10 16:03:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 16:42:36","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401886666109947908","tweetText":
"Pré-réservez Pokémon Diamant Étincelant et Pokémon Perle Scintillante dès maintenant !\n\nLa génération Pokémon la plus attendue des joueurs arrive le 19 novembre sur Nintendo Switch.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Nintendo France","screenName":
"@NintendoFrance"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"pokemon go"},{"targetingType":
"Age","targetingValue":
"13 and up"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 16:33:56"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 16:35:09","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401934644304658433","tweetText":
"Nous pouvons tous, à notre niveau, contribuer à un futur plus durable.\nAvec notre initiative #UnGestePourDemain, nous avons demandé à Ilona Smet et Juan Arbalaez de partager leurs petits gestes éco-responsables au quotidien.\n\nEt vous, quel est votre geste pour demain ? https://t.co/QD4a8t0kw5","urls":
[],"mediaUrls":
["https://t.co/QD4a8t0kw5"]},"advertiserInfo":
{"advertiserName":
"Volvo Car France","screenName":
"@VolvoCarFR"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Locations","targetingValue":
"France"}],"impressionTime":
"2021-06-10 16:11:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 16:41:33","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400461465182638081","tweetText":
"[Travaux d’été] 🚧🚆Cet été en #IDF les travaux sont partout, car ils sont pour tous ! Nous sommes mobilisés au côté de @RATPgroup et @Actu_Transilien pour vous offrir un réseau de transport toujours plus fiable. \nToutes les infos 👇","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IDF Mobilités","screenName":
"@IDFmobilites"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@le_Parisien"},{"targetingType":
"Locations","targetingValue":
"Ile-de-France"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-10 17:00:22"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 17:01:51","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402652032545308675","tweetText":
"Magnum présente : \"\"Miley in Layers\". Prenez vos écouteurs et écoutez le show exclusif de Miley Cyrus en 8 Dimensions. Disponible dès maintenant.  \n#MileyInLayers #ShowYourLayers #MileyByMagnum","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Magnum France","screenName":
"@Magnum_France"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-10 17:00:22"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 17:00:26","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400893922449182723","tweetText":
"Derrière chaque enseignant, médecin et agriculteur se trouve un expert informatique pour répondre aux défis complexes d'aujourd'hui. Nous avons pour mission de les accompagner avec nos solutions, du poste client au datacenter. #SmarterSolutions","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Lenovo","screenName":
"@Lenovo"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Computer programming"},{"targetingType":
"Conversation topics","targetingValue":
"Government/Education"},{"targetingType":
"Conversation topics","targetingValue":
"Entrepreneurship"},{"targetingType":
"Conversation topics","targetingValue":
"Education Related"},{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-10 17:04:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 18:09:19","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"Spotlight","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 14:41:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 14:42:00","engagementType":
"SpotlightView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1402892245313933318","tweetText":
"📢 [ANNONCE] AXA France aux côtés de ses clients restaurateurs pour la reprise économique.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"AXAFrance","screenName":
"@AXAFrance"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"France"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-06-10 14:42:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 14:42:45","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 13:10:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 13:10:26","engagementType":
"TrendView"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1384583743730561030","tweetText":
"Voici le nouvel iMac. 7 superbes couleurs. Design incroyablement fin. Écran Retina 4.5K de 24 pouces. Les meilleurs micros, enceintes et caméra de Mac jamais conçus. Avec la superpuissance de la puce Apple M1.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-04-21 09:52:44"},"engagementAttributes":
[{"engagementTime":
"2021-04-21 09:52:52","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-21 09:53:14","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1380443994782638080","tweetText":
"At Glencore, people are at the heart of our business, and prioritising their safety is one of our core values.\n\nThat’s why we're committed to operating responsibly and taking a preventative approach to establishing a #SafeWork culture.\n\nLearn more about our Values here.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Glencore","screenName":
"@Glencore"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"banking"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-21 13:32:09"},"engagementAttributes":
[{"engagementTime":
"2021-04-21 13:34:32","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-21 13:32:25","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-04-21 13:32:26","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-04-21 13:32:10","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-21 13:32:17","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-21 13:32:41","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-04-21 13:34:34","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-04-21 13:34:33","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-21 13:34:34","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-04-21 13:32:33","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-04-21 13:34:34","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-04-21 13:32:39","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1370426821741703168","tweetText":
"RT @ubereats_fr: Ca pédale dans la semoule... Et vous, #CouscousBoulettes ou #CouscousMerguez ? #ParlonsBouffe","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Uber Eats #EatLocal","screenName":
"@UberEats"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Eater-EMEA-Active Eaters"},{"targetingType":
"Locations","targetingValue":
"74100"},{"targetingType":
"Age","targetingValue":
"18 to 54"}],"impressionTime":
"2021-04-21 13:50:34"},"engagementAttributes":
[{"engagementTime":
"2021-04-21 13:50:37","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1379429246037229574","tweetText":
"Avec les AirPods Pro au design personnalisable, le monde devient votre terrain de jeu.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-04-21 06:29:30"},"engagementAttributes":
[{"engagementTime":
"2021-04-21 06:29:53","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-04-21 06:29:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-21 06:29:53","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-04-21 06:29:46","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-04-21 06:29:42","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-04-21 06:29:42","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-04-21 06:29:40","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-04-21 06:29:45","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-04-21 06:29:42","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-04-21 06:29:49","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-04-21 06:30:44","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-21 06:29:52","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-04-21 06:29:41","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1384583743730561030","tweetText":
"Voici le nouvel iMac. 7 superbes couleurs. Design incroyablement fin. Écran Retina 4.5K de 24 pouces. Les meilleurs micros, enceintes et caméra de Mac jamais conçus. Avec la superpuissance de la puce Apple M1.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-04-21 11:22:41"},"engagementAttributes":
[{"engagementTime":
"2021-04-21 11:22:44","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-04-21 11:46:32","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-21 11:22:47","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-04-21 11:22:48","engagementType":
"VideoSession"},{"engagementTime":
"2021-04-21 11:22:47","engagementType":
"VideoContentPlayback25"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-10 21:43:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 05:40:57","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401846479199875073","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-10 21:19:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 21:21:50","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-10 21:20:20","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-10 21:20:23","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-10 21:21:53","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-10 21:26:25","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-10 21:26:41","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-10 21:20:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-10 21:20:21","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-10 21:21:50","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-10 21:21:47","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-10 21:31:53","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-10 21:26:29","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-10 21:20:17","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-10 21:20:20","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-10 21:20:25","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-10 21:20:18","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-10 21:20:19","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-10 21:31:52","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-10 21:21:50","engagementType":
"VideoContentShortFormComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950401369411590","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-10 21:26:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 21:43:44","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395698296782426114","tweetText":
"Your mission is simple. You trade, you get rewarded with EQUOS Origin tokens. #EQO how many did you get today?","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"EQONEX","screenName":
"@eqonex"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ripple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@StellarOrg"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Dashpay"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CharlieShrem"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Neo_Blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"Follower look-alikes","targetingValue":
"@cburniske"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Age","targetingValue":
"18 to 54"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-10 21:31:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 21:43:40","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-10 21:43:47","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-10 21:19:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 21:19:21","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-10 21:19:22","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-10 21:19:19","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-10 21:19:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-10 21:19:17","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-10 21:19:22","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-10 21:19:22","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 19:53:51"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 19:54:49","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 19:43:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 19:43:19","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 19:32:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 19:32:30","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79153","name":
"#IONIQ5","description":
"La nouvelle mobilité électrique."},"advertiserInfo":
{"advertiserName":
"Hyundai France","screenName":
"@HyundaiFrance"},"impressionTime":
"2021-06-10 20:30:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-10 20:30:29","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-11 05:40:56"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 05:45:14","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401898495267704839","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-11 05:40:56"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 05:44:46","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 05:44:45","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 05:44:43","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-11 05:40:56"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 05:44:16","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 05:44:18","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 05:44:16","engagementType":
"VideoContentPlayback75"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1394300230154309639","tweetText":
"Eine ausreichende Stromversorgung ist jederzeit ein zentrales Thema. Am 15.06.21 treffen sich die Akteure der Schweizer Stromwirtschaft digital. Jetzt bereits das Datum notieren. https://t.co/NLpDyhLEEp\n#PowertageDigitalEvent2021 #Stromwirtschaft https://t.co/JYrYzSi72O","urls":
["https://t.co/NLpDyhLEEp"],"mediaUrls":
["https://t.co/JYrYzSi72O"]},"advertiserInfo":
{"advertiserName":
"Powertage","screenName":
"@Powertage"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@tech_fund"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 15:01:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 15:03:21","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1375300944183750656","tweetText":
"🤩 Every Piece Is A Cute Animal! \n🧩 It's not just a puzzle 😍 It's art! \nGet it 👉 https://t.co/X1pIE9gsxC https://t.co/YeGcDCAn9i","urls":
["https://t.co/X1pIE9gsxC"],"mediaUrls":
["https://t.co/YeGcDCAn9i"]},"advertiserInfo":
{"advertiserName":
"Pressl Store","screenName":
"@presslstore"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-11 15:32:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 15:38:48","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 15:38:39","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402332269877022729","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/629LrjLfJc\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/629LrjLfJc"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"computer security information"},{"targetingType":
"Keywords","targetingValue":
"cyber security conference"},{"targetingType":
"Keywords","targetingValue":
"#datasecurity"},{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Keywords","targetingValue":
"it security conference"},{"targetingType":
"Keywords","targetingValue":
"it security"},{"targetingType":
"Keywords","targetingValue":
"data security"},{"targetingType":
"Keywords","targetingValue":
"network security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"infosec"},{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 15:48:54"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:16:26","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948542978117632","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 15:24:33"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 15:24:43","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402976851467898882","tweetText":
"Springe in aberwitzigem Tempo durch Dimensionen und durchkreuze die Pläne eines fiesen Superschurken! Hol dir jetzt das neue #RatchetPS5 exklusiv für #PS5","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PlayStationDE","screenName":
"@PlayStationDE"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Online gaming"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 15:32:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 15:38:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 15:38:47","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1250749449422409729","tweetText":
"L'intelligence artificielle pourrait créer 21 millions d'emplois d'ici 2030! 🧐 😮 👏\n\nL'IA soutient les entreprises et les administrations dans leur évolution et leur adaptation à leur environnement.\n\nRegardez comment grâce à cette vidéo!\n\n#ia #stratégie https://t.co/Jsj5Mp2YrL","urls":
[],"mediaUrls":
["https://t.co/Jsj5Mp2YrL"]},"advertiserInfo":
{"advertiserName":
"Geneva Intelligence (GI)","screenName":
"@geneva_intell"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 14:32:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 14:33:13","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 14:33:42","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948741741989894","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 14:13:26"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 14:13:58","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ethereumJoseph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@boxmining"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@lopp"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CharlieShrem"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VentureCoinist"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@TheBlock__"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CryptoHayes"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MessariCrypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@whale_alert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 06:20:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 06:20:44","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 06:20:45","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1367156855395483648","tweetText":
"Tausche dein Gesicht mit dem von Promis! 👥 🔥\nFüge dein Gesicht in Videos und GIFs ein. Verwandle dich in wen du willst 😎\nKreiere lustige REFACE GIFs und Videos mit dir selbst 🔥🔥🔥\nHab Spaß &amp; begeistere deine Freunde 🎉\nDie beste Gesichtstausch-Qualität im App Store⭐⭐⭐⭐⭐","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Reface","screenName":
"@reface_app"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"face"},{"targetingType":
"Conversation topics","targetingValue":
"Marvel Universe"},{"targetingType":
"Conversation topics","targetingValue":
"Spider-Man"},{"targetingType":
"App Activity","targetingValue":
"Install Reface: Face Swap Videos IOS 14 Day"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 06:20:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 06:24:02","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 06:24:04","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 06:23:58","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 06:29:35","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1375300944183750656","tweetText":
"🤩 Every Piece Is A Cute Animal! \n🧩 It's not just a puzzle 😍 It's art! \nGet it 👉 https://t.co/X1pIE9gsxC https://t.co/YeGcDCAn9i","urls":
["https://t.co/X1pIE9gsxC"],"mediaUrls":
["https://t.co/YeGcDCAn9i"]},"advertiserInfo":
{"advertiserName":
"Pressl Store","screenName":
"@presslstore"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 06:20:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 06:23:03","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 06:23:02","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 06:23:48","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401660168845266944","tweetText":
"Nos spécialistes vous accompagnent tout au long du processus de planification de votre succession avec des solutions sur mesure. En savoir plus.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bank CIC","screenName":
"@Bank_CIC"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 06:20:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 06:22:31","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 06:22:45","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-11 06:20:21"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 06:20:28","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 06:20:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 06:20:27","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 06:20:27","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 06:20:25","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 06:20:29","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-11 06:20:30","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 06:20:30","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-11 06:20:29","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 06:20:30","engagementType":
"VideoContentPlaybackComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950696967217153","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 11:25:54"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 11:25:56","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 11:33:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 11:33:23","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 11:38:11","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 11:33:24","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 11:33:28","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 11:33:24","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-11 11:38:04","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 11:38:45","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 11:38:07","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 11:33:23","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 11:33:25","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 11:33:24","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-11 11:38:37","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402556010808713225","tweetText":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard.\nEntdecke jetzt, wie sicher es ist.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 11:38:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 11:38:48","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948542978117632","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 10:42:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 10:42:45","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1375300944183750656","tweetText":
"🤩 Every Piece Is A Cute Animal! \n🧩 It's not just a puzzle 😍 It's art! \nGet it 👉 https://t.co/X1pIE9gsxC https://t.co/YeGcDCAn9i","urls":
["https://t.co/X1pIE9gsxC"],"mediaUrls":
["https://t.co/YeGcDCAn9i"]},"advertiserInfo":
{"advertiserName":
"Pressl Store","screenName":
"@presslstore"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-11 10:42:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 10:43:29","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 10:43:28","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 10:43:19","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349013672190996485","tweetText":
"En demander plus à l’iPhone pour en demander moins à la planète.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 10:42:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 10:42:29","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 10:42:37","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 10:42:31","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400787022462193668","tweetText":
"Sichern Sie sich jetzt Ihren Platz für den Digital-Event vom 15. Juni und werden Sie Teil unserer Community. Hier registrieren und dabei sein, wenn sich die Schweizer Energiebranche digital trifft. #powertagedigitalevent2021 #stromwirtschaft \nhttps://t.co/ahOyEHtt3m https://t.co/9XcL3GREKY","urls":
["https://t.co/ahOyEHtt3m"],"mediaUrls":
["https://t.co/9XcL3GREKY"]},"advertiserInfo":
{"advertiserName":
"Powertage","screenName":
"@Powertage"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@tech_fund"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 10:42:18"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 10:42:20","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1401950401369411590","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 10:43:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 10:43:51","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1366602458022047745","tweetText":
"Buy $BTC for as little as US$1\n\n§tack §ats on your terms.\nCredit card New users enjoy 0% credit/debit card fees too!\n\nInstall and Get Started Now.\n#Bitcoin #BTC #CRO","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@ftfinancenews"},{"targetingType":
"Follower look-alikes","targetingValue":
"@elonmusk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ledger"},{"targetingType":
"Follower look-alikes","targetingValue":
"@novogratz"},{"targetingType":
"Follower look-alikes","targetingValue":
"@YahooFinance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BloombergTV"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@rogerkver"},{"targetingType":
"Follower look-alikes","targetingValue":
"@EOSIO"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"Install Crypto.com - Buy Bitcoin Now ANDROID All"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:45:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:45:02","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402556010808713225","tweetText":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard.\nEntdecke jetzt, wie sicher es ist.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:42:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:42:41","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:42:38","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:43:03","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:43:01","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-11 17:43:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:43:02","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:45:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:45:49","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:45:51","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:45:52","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1383146402629496837","tweetText":
"Start your #AIOps journey with AI-driven ITOps solutions from IBM.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IBM Cloud","screenName":
"@IBMcloud"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"network security"},{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:44:24","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:44:27","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-11 17:44:25","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:44:30","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:44:27","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-11 17:44:29","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:44:25","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-11 17:44:26","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948542978117632","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:43:13","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:44:51","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:44:52","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-11 17:44:50","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 17:44:50","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:44:52","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 17:44:48","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:44:56","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:44:52","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 17:44:53","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-11 17:44:52","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402556010808713225","tweetText":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard.\nEntdecke jetzt, wie sicher es ist.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 17:39:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:40:09","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:39:59","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:40:02","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:39:54","engagementType":
"ChargeableImpression"},{"engagementTime":
"2021-06-11 17:39:56","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-11 17:39:55","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1383146402629496837","tweetText":
"Start your #AIOps journey with AI-driven ITOps solutions from IBM.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IBM Cloud","screenName":
"@IBMcloud"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Keywords","targetingValue":
"network security"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:39:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:42:02","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 17:42:01","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-11 17:42:00","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:42:03","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948741741989894","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:39:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:41:00","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1399324612140404740","tweetText":
"Nous gardons un œil sur le marché pour que vous puissiez vous détendre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PostFinance","screenName":
"@PostFinance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@zeitonline"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:45:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:46:08","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:46:14","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-11 17:46:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:46:13","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:46:10","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 17:46:11","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:46:10","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-11 17:45:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:46:00","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:39:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:39:26","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 17:39:28","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-11 17:39:28","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 17:39:27","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-11 17:39:15","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 17:39:13","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:39:18","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:39:15","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:39:36","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:39:19","engagementType":
"VideoContent6secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402989940737073159","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952751"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25901640"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952750"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 17:17:03"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:18:43","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-11 17:39:12","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:18:40","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 17:19:30","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:42:26","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-11 17:18:42","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-11 17:18:28","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 17:18:43","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 17:18:36","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 17:18:32","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 17:39:11","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"saving"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"save"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-11 17:39:10"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 17:40:43","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"79745","name":
"#Loki","description":
"En streaming dès maintenant sur Disney+"},"advertiserInfo":
{"advertiserName":
"Disney+ FR","screenName":
"@DisneyPlusFR"},"impressionTime":
"2021-06-11 13:24:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 13:24:36","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950401369411590","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 13:40:55"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 13:40:57","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1401950696967217153","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 13:29:53"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 13:30:28","engagementType":
"ChargeableImpression"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-11 22:07:00"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 22:07:00","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-11 23:12:38"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 23:12:39","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 00:29:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 00:29:57","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 00:29:52","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 00:29:58","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 00:29:58","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-12 00:30:05","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 00:29:54","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 00:29:49","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 00:30:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 00:29:58","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1375300944183750656","tweetText":
"🤩 Every Piece Is A Cute Animal! \n🧩 It's not just a puzzle 😍 It's art! \nGet it 👉 https://t.co/X1pIE9gsxC https://t.co/YeGcDCAn9i","urls":
["https://t.co/X1pIE9gsxC"],"mediaUrls":
["https://t.co/YeGcDCAn9i"]},"advertiserInfo":
{"advertiserName":
"Pressl Store","screenName":
"@presslstore"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-12 00:29:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 00:32:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 00:32:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 00:32:23","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400406914341621762","tweetText":
"🎁 Get yourself a nice treat:\nAs you save 70% off your NordVPN plan, you can afford it.\nAnd because you're reading this, get an extra month for free:  https://t.co/WXDbKPsczo https://t.co/SL1nyQfYF2","urls":
["https://t.co/WXDbKPsczo"],"mediaUrls":
["https://t.co/SL1nyQfYF2"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"online security"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ProtonVPN"},{"targetingType":
"Age","targetingValue":
"13 to 54"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-12 00:29:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 00:31:27","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 00:31:29","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 00:31:30","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 00:31:37","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 00:31:53","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 00:31:33","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 00:31:37","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 00:31:33","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 00:31:30","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 00:31:35","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 00:31:37","engagementType":
"VideoContentShortFormComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397809946360573952","tweetText":
"🔥Trade BTCUSD &amp; ETHUSD perpetuals with up to 100x leverage \n \n⚡Take long or short positions with no expiry date \n⚡Stake #CRO for lower trading fees\n\nLearn More 👇\nhttps://t.co/xVogp1j6YL https://t.co/AWwictJtJG","urls":
["https://t.co/xVogp1j6YL"],"mediaUrls":
["https://t.co/AWwictJtJG"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ripple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@StellarOrg"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Dashpay"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 00:29:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 00:30:58","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 00:30:57","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402661766342062082","tweetText":
"Because many of you asked for it... #Dogecoin is now available on Swissquote, ready to trade. \n👉 Welcome to the 22nd crypto listed on Swissquote!\n▶️ Learn more: https://t.co/mXOLAZaO40 https://t.co/Bu0ReaIcyW","urls":
["https://t.co/mXOLAZaO40"],"mediaUrls":
["https://t.co/Bu0ReaIcyW"]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 19:33:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 19:34:36","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-11 19:34:39","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-11 19:34:35","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-11 19:34:41","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-11 19:34:42","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-11 19:34:36","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-11 19:34:37","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-11 19:34:34","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-11 19:34:42","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-11 19:34:39","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-11 19:34:34","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-11 19:34:32","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-11 20:20:39","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1402628594589966338","tweetText":
"Heute ist der letzte Tag des First Pitch der Swiss Innovation Challenge im Haus der Wirtschaft in Pratteln. Unsere Jury durfte in den letzten drei Tagen viele interessante Geschäftsideen kennenlernen. \n\nWir freuen uns auf die letzten Pitches!\n\n@blkb_ch @FHNW\n#SIC https://t.co/Pr3LL5Ii3K","urls":
[],"mediaUrls":
["https://t.co/Pr3LL5Ii3K"]},"advertiserInfo":
{"advertiserName":
"Swiss Innovation Challenge #SIC","screenName":
"@sic_swiss"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Green solutions"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Conversation topics","targetingValue":
"Entrepreneurship"},{"targetingType":
"Conversation topics","targetingValue":
"Small business"},{"targetingType":
"Conversation topics","targetingValue":
"Business & finance"},{"targetingType":
"Conversation topics","targetingValue":
"Business news"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"25 to 49"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-11 18:28:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-11 18:29:01","engagementType":
"ChargeableImpression"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400406914341621762","tweetText":
"🎁 Get yourself a nice treat:\nAs you save 70% off your NordVPN plan, you can afford it.\nAnd because you're reading this, get an extra month for free:  https://t.co/WXDbKPsczo https://t.co/SL1nyQfYF2","urls":
["https://t.co/WXDbKPsczo"],"mediaUrls":
["https://t.co/SL1nyQfYF2"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"online security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ProtonVPN"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"13 to 54"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-12 15:57:33"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:57:59","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:57:57","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:57:57","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-12 15:41:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:43:20","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:43:19","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:33:32","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:33:30","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:33:31","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402989578735128597","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Online gaming"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:30:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:30:59","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:30:55","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 15:30:58","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 15:30:59","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 15:30:52","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:30:55","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400774238299111430","tweetText":
"Un essai routier d’un genre particulier: découvre pendant 24h nos modèles ID entièrement électriques. Besoin d'aller au bureau ou faire du sport? Envie de profiter du trajet avec ta famille et des amis? Teste tes modèles ID préférés selon tes envies et ton humeur.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla - Model 3"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-12 15:41:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:43:12","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 15:43:10","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:43:13","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948741741989894","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:36:39","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402991626083995651","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952751"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25901640"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952750"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:33:36","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:33:40","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-12 15:30:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:31:37","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:31:39","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 15:31:53","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1383146405343154181","tweetText":
"Lower costs, improve customer experiences and deliver 5G and #edgecomputing services faster.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IBM Cloud","screenName":
"@IBMcloud"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Keywords","targetingValue":
"network security"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:41:46","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 15:43:00","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 15:41:42","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 15:41:43","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 15:43:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:41:41","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 15:41:43","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-12 15:41:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:41:47","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 15:41:43","engagementType":
"VideoContentViewV2"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950696967217153","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:36:20","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Keywords","targetingValue":
"save"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"money"},{"targetingType":
"Keywords","targetingValue":
"saving"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Keywords","targetingValue":
"stocks"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:36:44","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399324399782842376","tweetText":
"Sie wünschen sich mehr Zeit für Ihre Träume? Entdecken Sie unsere E-Vermögensverwaltung.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"PostFinance","screenName":
"@PostFinance"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Interests","targetingValue":
"Green solutions"},{"targetingType":
"Follower look-alikes","targetingValue":
"@zeitonline"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:38:34","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 15:38:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:38:37","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402333291559149569","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/0io4RMQDfG\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/0io4RMQDfG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Keywords","targetingValue":
"infosec"},{"targetingType":
"Keywords","targetingValue":
"data security"},{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 15:41:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 15:43:08","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 15:43:06","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1400084548961116165","tweetText":
"L'app Yuh va changer la manière dont les Suisses utilisent leur argent. Découvrez comment! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"save"},{"targetingType":
"Keywords","targetingValue":
"saving"},{"targetingType":
"Keywords","targetingValue":
"personal finance"},{"targetingType":
"Keywords","targetingValue":
"money"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 12:33:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 12:36:28","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402988967272718345","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"icloud"},{"targetingType":
"Keywords","targetingValue":
"#icloud"},{"targetingType":
"Follower look-alikes","targetingValue":
"@MacRumors"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleSupport"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppStore"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-12 12:30:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 12:32:15","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 12:32:17","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1401950545552752646","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 12:33:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 12:35:52","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1401948282650234885","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 12:33:46"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 12:35:17","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 07:08:48"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 07:08:50","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402990703400034318","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@MacRumors"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleSupport"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppStore"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 07:08:04"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 07:08:19","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 07:08:22","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 07:38:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 07:08:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 07:38:13","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 07:38:15","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 07:08:17","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 07:08:21","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 07:08:21","engagementType":
"VideoContent6secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-12 07:08:04"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 07:08:51","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 07:08:43","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 07:38:09","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 07:38:23","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 07:23:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:00:42","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400406914341621762","tweetText":
"🎁 Get yourself a nice treat:\nAs you save 70% off your NordVPN plan, you can afford it.\nAnd because you're reading this, get an extra month for free:  https://t.co/WXDbKPsczo https://t.co/SL1nyQfYF2","urls":
["https://t.co/WXDbKPsczo"],"mediaUrls":
["https://t.co/SL1nyQfYF2"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@ProtonVPN"},{"targetingType":
"Keywords","targetingValue":
"online security"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"13 to 54"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-12 07:08:04"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 12:31:47","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 07:38:42","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 12:30:23","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 11:35:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 12:31:48","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 07:38:44","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 07:38:44","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 07:39:29","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-12 17:21:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:52:44","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:52:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:52:42","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 18:52:44","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:52:48","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:52:42","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402991626083995651","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952751"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25901640"},{"targetingType":
"Retargeting campaign engager","targetingValue":
"Retargeting campaign engager: 25952750"},{"targetingType":
"Retargeting engagement type","targetingValue":
"Retargeting engagement type: 2"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-12 17:40:26"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:51:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:51:53","engagementType":
"VideoContentPlaybackStart"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395412511122497540","tweetText":
"Here’s how user feedback tools can make those important product decisions a little easier. Try Hotjar free today.🔥","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Hotjar","screenName":
"@hotjar"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Green solutions"},{"targetingType":
"Website Activity"},{"targetingType":
"Website Activity","targetingValue":
"Hotjar 2020 - All visitors to the website"},{"targetingType":
"List","targetingValue":
"Builtwith Signups + marketing exclusion requests (USE AS NEGATIVE AUDIENCE)"},{"targetingType":
"List","targetingValue":
"July 2020 -  Live Hotjar Sites (builtwith)"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:31:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:31:42","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-12 20:31:42","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-12 20:31:43","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 20:31:40","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 20:31:48","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 20:32:02","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 20:31:41","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 20:31:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 20:31:45","engagementType":
"VideoContent6secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402332269877022729","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/629LrjLfJc\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/629LrjLfJc"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"infosec"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"#Pentest"},{"targetingType":
"Keywords","targetingValue":
"data security"},{"targetingType":
"Keywords","targetingValue":
"#datasecurity"},{"targetingType":
"Keywords","targetingValue":
"it security"},{"targetingType":
"Keywords","targetingValue":
"#cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:35:00"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:35:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 20:36:14","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948542978117632","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:08:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:09:44","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1293643891166543872","tweetText":
"Datadog’s single UI allows you to correlate logs with related metrics and application traces. Spend less time troubleshooting and more time on product innovation:","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Datadog, Inc.","screenName":
"@datadoghq"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#debugging"},{"targetingType":
"List"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:08:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:09:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 20:09:37","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950545552752646","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:08:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:09:35","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 20:31:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:31:36","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 20:35:00"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:35:01","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 20:08:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:08:29","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1347533705682833408","tweetText":
"We are thrilled to announce TypingDNA Focus - Analyze your mood by the way you type. Subscribe for limited early access https://t.co/SCEgn37EMe","urls":
["https://t.co/SCEgn37EMe"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TypingDNA","screenName":
"@TypingDNA"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"evernote"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-12 20:35:00"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:35:10","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 20:35:11","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 20:35:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 20:35:12","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-12 20:35:12","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-12 20:35:09","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402661766342062082","tweetText":
"Because many of you asked for it... #Dogecoin is now available on Swissquote, ready to trade. \n👉 Welcome to the 22nd crypto listed on Swissquote!\n▶️ Learn more: https://t.co/mXOLAZaO40 https://t.co/Bu0ReaIcyW","urls":
["https://t.co/mXOLAZaO40"],"mediaUrls":
["https://t.co/Bu0ReaIcyW"]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 20:35:00"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 20:37:35","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 20:37:33","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 20:37:35","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-12 20:37:36","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 20:36:46","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 20:37:34","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 20:37:35","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-12 20:37:36","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 20:36:48","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 20:37:34","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402989578735128597","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Online gaming"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 18:57:28"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:57:35","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 18:57:31","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:57:33","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 18:57:31","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 19:48:29","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:57:38","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 19:48:30","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:57:37","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 19:46:56","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-12 18:24:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:24:29","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-12 19:42:23","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:31:59","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 18:30:41","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:24:28","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 18:32:27","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 18:24:29","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 18:32:49","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:24:32","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:24:32","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 18:32:27","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-12 18:24:26","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:30:41","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 18:24:29","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-12 18:24:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:24:28","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 18:31:59","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 19:42:20","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400406914341621762","tweetText":
"🎁 Get yourself a nice treat:\nAs you save 70% off your NordVPN plan, you can afford it.\nAnd because you're reading this, get an extra month for free:  https://t.co/WXDbKPsczo https://t.co/SL1nyQfYF2","urls":
["https://t.co/WXDbKPsczo"],"mediaUrls":
["https://t.co/SL1nyQfYF2"]},"advertiserInfo":
{"advertiserName":
"NordVPN","screenName":
"@NordVPN"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@ProtonVPN"},{"targetingType":
"Keywords","targetingValue":
"online security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Age","targetingValue":
"13 to 54"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-12 18:24:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:35:42","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:35:42","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:35:41","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402988967272718345","tweetText":
"Étiquettes de confidentialité. Découvrez les données collectées par les apps, avant de les télécharger.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@MacRumors"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Apple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleSupport"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppStore"},{"targetingType":
"Follower look-alikes","targetingValue":
"@AppleMusic"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 18:44:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:59:36","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 18:59:36","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:59:38","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 18:59:39","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:59:36","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-12 18:59:36","engagementType":
"VideoContentPlaybackComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402661766342062082","tweetText":
"Because many of you asked for it... #Dogecoin is now available on Swissquote, ready to trade. \n👉 Welcome to the 22nd crypto listed on Swissquote!\n▶️ Learn more: https://t.co/mXOLAZaO40 https://t.co/Bu0ReaIcyW","urls":
["https://t.co/mXOLAZaO40"],"mediaUrls":
["https://t.co/Bu0ReaIcyW"]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 18:24:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:50:07","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:50:12","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Gemini"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Gender","targetingValue":
"Men"}],"impressionTime":
"2021-06-12 18:24:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:36:10","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 18:44:24","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:36:03","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:36:11","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:36:07","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402332269877022729","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/629LrjLfJc\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/629LrjLfJc"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"infosec"},{"targetingType":
"Keywords","targetingValue":
"#cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"data security"},{"targetingType":
"Keywords","targetingValue":
"it security"},{"targetingType":
"Keywords","targetingValue":
"#datasecurity"},{"targetingType":
"Keywords","targetingValue":
"#Pentest"},{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 18:57:28"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:58:12","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 18:58:07","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397809946360573952","tweetText":
"🔥Trade BTCUSD &amp; ETHUSD perpetuals with up to 100x leverage \n \n⚡Take long or short positions with no expiry date \n⚡Stake #CRO for lower trading fees\n\nLearn More 👇\nhttps://t.co/xVogp1j6YL https://t.co/AWwictJtJG","urls":
["https://t.co/xVogp1j6YL"],"mediaUrls":
["https://t.co/AWwictJtJG"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ripple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@StellarOrg"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Dashpay"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 18:24:24"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:51:51","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 18:51:49","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 18:51:52","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"stocks"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Keywords","targetingValue":
"saving"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"save"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-12 18:44:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 18:59:42","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"Trends","promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:34:49","engagementType":
"TrendView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402554726978367490","tweetText":
"Einfach sicher, auch wenn es schnell gehen muss: Mobile Zahlung mit Mastercard. Entdecke jetzt, wie sicher es ist.","urls":
[],"mediaUrls":
[]},"promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:35:48","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 21:36:10","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 21:35:51","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 21:35:51","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395408727356985344","tweetText":
"Sometimes, the numbers alone aren’t enough. Sure, they’ll show you there’s an issue, but they won’t show you what the issue actually is. With Hotjar you can get to the bottom of the situation fast, by getting direct input from your users. Goodbye guesswork, hello happy users.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Hotjar","screenName":
"@hotjar"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Green solutions"},{"targetingType":
"Website Activity"},{"targetingType":
"Website Activity","targetingValue":
"Hotjar 2020 - All visitors to the website"},{"targetingType":
"List","targetingValue":
"Builtwith Signups + marketing exclusion requests (USE AS NEGATIVE AUDIENCE)"},{"targetingType":
"List","targetingValue":
"July 2020 -  Live Hotjar Sites (builtwith)"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:35:28","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 23:28:33","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 21:35:51","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399869269769437186","tweetText":
"The future of rheumatology involves innovative medicines and a diverse portfolio of treatments for patients. Join us at EULAR to learn more: https://t.co/Af4bVybdQP","urls":
["https://t.co/Af4bVybdQP"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"AbbVie","screenName":
"@abbvie"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#inflammation"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:36:27","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 21:36:05","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 21:36:10","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401948542978117632","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:38:14","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1326651971009449987","tweetText":
"Pinpoint hard-to-reproduce problems in your production code without affecting your application's performance. Datadog's Continuous Profiler is a production code profiler that enables you to analyze code-level performance across your entire environment, with minimal overhead.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Datadog, Inc.","screenName":
"@datadoghq"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"requests go"},{"targetingType":
"Age","targetingValue":
"21 to 54"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:37:11","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 21:37:13","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 21:37:31","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401950696967217153","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 21:34:49"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 21:36:42","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400416370010038276","tweetText":
"Rechtzeitig zu unserer Premiere, dem Digital-Event vom 15. Juni 2021, ist unsere neue Webseite bzw. Community-Plattform live gegangen. Wir vernetzen den geballten Power der der Schweizer Stromwirtschaft.\nhttps://t.co/zTBv4lFOqA\n\n#powertage https://t.co/bP07jnD9E6","urls":
["https://t.co/zTBv4lFOqA"],"mediaUrls":
["https://t.co/bP07jnD9E6"]},"advertiserInfo":
{"advertiserName":
"Powertage","screenName":
"@Powertage"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@tech_fund"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 23:28:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:28:37","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1379030606852587523","tweetText":
"Analyze your mood by the way you type, and discover productivity patterns using TypingDNA Focus app. \n\nGet unlimited early access before the official launch:  https://t.co/Zy3Xx1hXtb\n\n#TypingDNAFocus #MoodTracker #ProductivityApp","urls":
["https://t.co/Zy3Xx1hXtb"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"TypingDNA","screenName":
"@TypingDNA"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"evernote"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-12 23:28:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:34:35","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 23:34:06","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 23:34:07","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395051862097809409","tweetText":
"The fourth edition of SmartSuisse will include a symposium and a congress, now incorporating a range of parallel series on Governance, Mobility, Energy &amp; Environment and Infrastructure.\n#SmartSuisse #Government #Mobility #Energy #Environment #Infrastructure","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"smartsuisse","screenName":
"@SmartSuisse"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 23:58:45"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:59:55","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1395412511122497540","tweetText":
"Here’s how user feedback tools can make those important product decisions a little easier. Try Hotjar free today.🔥","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Hotjar","screenName":
"@hotjar"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Green solutions"},{"targetingType":
"Website Activity"},{"targetingType":
"Website Activity","targetingValue":
"Hotjar 2020 - All visitors to the website"},{"targetingType":
"List","targetingValue":
"Builtwith Signups + marketing exclusion requests (USE AS NEGATIVE AUDIENCE)"},{"targetingType":
"List","targetingValue":
"July 2020 -  Live Hotjar Sites (builtwith)"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 23:28:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:28:57","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 23:29:19","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 23:28:59","engagementType":
"VideoContentMrcView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1397809946360573952","tweetText":
"🔥Trade BTCUSD &amp; ETHUSD perpetuals with up to 100x leverage \n \n⚡Take long or short positions with no expiry date \n⚡Stake #CRO for lower trading fees\n\nLearn More 👇\nhttps://t.co/xVogp1j6YL https://t.co/AWwictJtJG","urls":
["https://t.co/xVogp1j6YL"],"mediaUrls":
["https://t.co/AWwictJtJG"]},"advertiserInfo":
{"advertiserName":
"Crypto.com","screenName":
"@cryptocom"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Follower look-alikes","targetingValue":
"@blockchain"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ripple"},{"targetingType":
"Follower look-alikes","targetingValue":
"@StellarOrg"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Dashpay"},{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@binance"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 23:28:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:29:07","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 23:29:08","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 23:29:09","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 23:29:19","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1326652597751717893","tweetText":
"Reduce end-user latency, lower cloud provider costs, and get deeper insights into code-level performance with Datadog's Continuous Profiler. Locate which functions (or lines of code) consume the most resources, such as CPU and memory. Try it yourself -&gt;","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Datadog, Inc.","screenName":
"@datadoghq"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@nodejs"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 54"}],"impressionTime":
"2021-06-12 23:28:29"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 23:31:29","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 23:31:33","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 23:31:37","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 23:31:30","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 23:31:35","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 23:31:37","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 23:32:18","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 23:31:37","engagementType":
"VideoContentShortFormComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1401948282650234885","tweetText":
"L’Espagne vous attend les bras grand ouverts 👐. Allez sur notre site web et choisissez votre destination favorite au meilleur prix et avec l’assurance de pouvoir la modifier sans frais.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia_fr","screenName":
"@Iberia_fr"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 19:49:14"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:49:34","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402554726978367490","tweetText":
"Einfach sicher, auch wenn es schnell gehen muss: Mobile Zahlung mit Mastercard. Entdecke jetzt, wie sicher es ist.","urls":
[],"mediaUrls":
[]},"promotedTrendInfo":
{"trendId":
"80210","name":
"#MobilePay","description":
"Immer dabei und sicher zur Hand - mobile Zahlung mit Mastercard."},"advertiserInfo":
{"advertiserName":
"MastercardCH","screenName":
"@MastercardCH"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 19:42:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:44:30","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 19:45:37","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 19:44:59","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 19:45:02","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 19:44:55","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 19:42:19"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:43:15","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 19:43:15","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 19:43:21","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 19:43:23","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-12 19:43:18","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 19:43:17","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-12 19:43:59","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 19:43:19","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-12 19:43:19","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 19:43:19","engagementType":
"VideoContentPlayback95"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1401950696967217153","tweetText":
"Spanien erwartet dich mit offenen Armen 👐. Wähle auf unserer Website dein Lieblingsziel zum besten Preis und mit der Sicherheit, ohne Gebühr umbuchen zu können.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Iberia","screenName":
"@Iberia_de"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbnb"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tripadvisor"},{"targetingType":
"Follower look-alikes","targetingValue":
"@British_Airways"},{"targetingType":
"Follower look-alikes","targetingValue":
"@KLM"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Ryanair"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Airbus"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 19:49:09"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:49:11","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1400084548961116165","tweetText":
"L'app Yuh va changer la manière dont les Suisses utilisent leur argent. Découvrez comment! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-12 19:48:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:48:57","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"SearchTweets","promotedTweetInfo":
{"tweetId":
"1400725824240865287","tweetText":
"Elle n’a pas sa pareille: Yuh, ta nouvelle app pour toutes les questions financières.😍 Paie, épargne et investis en quelques clics. Inscris-toi gratuitement maintenant et profite de tous les avantages! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-12 19:48:42"},"engagementAttributes":
[{"engagementTime":
"2021-06-12 19:48:49","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-12 19:48:48","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-12 19:48:45","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-12 19:48:52","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-12 19:48:50","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-12 19:48:49","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-12 19:48:49","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-12 19:48:44","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-12 19:48:51","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-12 19:48:46","engagementType":
"VideoContentMrcView"}]}]}}}},{"ad":
{"adsUserData":
{"adEngagements":
{"engagements":
[{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401898495267704839","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-13 08:42:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 08:44:08","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 08:44:06","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 08:44:04","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 08:44:08","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-13 08:44:08","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-13 08:44:07","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 08:44:10","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 08:44:08","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-13 08:44:01","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400084548961116165","tweetText":
"L'app Yuh va changer la manière dont les Suisses utilisent leur argent. Découvrez comment! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-13 08:42:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 08:43:17","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"}],"impressionTime":
"2021-06-13 08:42:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 08:43:48","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 08:43:38","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 08:43:38","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399868708793823235","tweetText":
"At this year’s EULAR, we’ll share new data from our rheumatology portfolio. Learn more: https://t.co/EbS3gyWYbU","urls":
["https://t.co/EbS3gyWYbU"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"AbbVie","screenName":
"@abbvie"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#inflammation"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-06-13 08:42:58"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 08:44:26","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 08:44:24","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 08:44:25","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 08:44:25","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 08:44:25","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 08:44:25","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 08:44:27","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:35:08","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1379658690215616512","tweetText":
"🎖 Navy SEAL team combat shorts - Extremely comfortable and excellent durability 👍\n🔥 Give you unlimited possibilities 💪 \nShop Now for 50% Off 👉 https://t.co/juUC4ldvH1 https://t.co/dqWr2HaIFV","urls":
["https://t.co/juUC4ldvH1"],"mediaUrls":
["https://t.co/dqWr2HaIFV"]},"advertiserInfo":
{"advertiserName":
"Iztore Shop","screenName":
"@iztore_co"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:03:55","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:03:46","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399906577050656769","tweetText":
"What do a WNBA star, astronaut, Miss America, scientist, author, doctor and IBM executive have in common? They bet big.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"IBM Cloud","screenName":
"@IBMcloud"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"data science"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"25 and up"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:38:42","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 13:39:00","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390580336061526018","tweetText":
"Switch to the UPC Giganet now &amp; start benefitting. 600 Mbit/s incl. UPC TV App for just 39 Swiss francs a month.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UPC Schweiz","screenName":
"@UPC_Switzerland"},"matchedTargetingCriteria":
[{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:39:32","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 13:39:36","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-13 13:39:37","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 13:39:34","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 13:39:36","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 13:39:36","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 13:39:37","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 13:39:32","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 13:39:38","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:39:30","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:03:19","engagementType":
"VideoContentPlaybackComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:34:33","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 13:34:35","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:02:57","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:34:34","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 13:34:33","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 13:34:42","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400774238299111430","tweetText":
"Un essai routier d’un genre particulier: découvre pendant 24h nos modèles ID entièrement électriques. Besoin d'aller au bureau ou faire du sport? Envie de profiter du trajet avec ta famille et des amis? Teste tes modèles ID préférés selon tes envies et ton humeur.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla - Model 3"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:04:02","engagementType":
"VideoContent6secView"},{"engagementTime":
"2021-06-13 14:03:59","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:04:04","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:03:55","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:04:05","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:03:58","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:04:05","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:03:56","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:04:02","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:04:09","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"ProfileTweets","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 13:13:30"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:13:49","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:13:48","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 13:13:48","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1403357888563879937","tweetText":
"Verdiene bis zu 500.000 GTA$ als Bonus, indem du Fahrzeuge in Fahrzeuglieferungen in #GTAOnline beschaffst.\n\nZudem kannst du noch mehr verdienen, indem du Fahrzeughandels-Missionen abschließt und dir so DOPPELTE GTA$ und RP sicherst.\n\nDas Angebot endet am 23. Juni.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Rockstar Games","screenName":
"@RockstarGames"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#nowplaying"},{"targetingType":
"List","targetingValue":
"gtao-018-136-gtaops4xb1pc-activeplayers-eu_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-018-137-gtaops4xb1pc-activeplayers-latamasia_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-029-gtaops4xb1pc-lapsedplayers-latamasia_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-028-gtaops4xb1pc-lapsedplayers-eu_18ce54ypdu8"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:04:25","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402333291559149569","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/0io4RMQDfG\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/0io4RMQDfG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:00:15","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 13:43:47","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:34:32","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:34:23","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 13:43:43","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 13:34:22","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 13:34:24","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:00:15","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:43:42","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401660168845266944","tweetText":
"Nos spécialistes vous accompagnent tout au long du processus de planification de votre succession avec des solutions sur mesure. En savoir plus.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Bank CIC","screenName":
"@Bank_CIC"},"matchedTargetingCriteria":
[{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Interests","targetingValue":
"Leadership"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:39:08","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:03:17","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:03:17","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 13:39:03","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:38:18","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:03:11","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:38:20","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 13:38:21","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:38:17","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1403024099119599617","tweetText":
"All the #market news you need to know in 5 minutes. Start your day off right with #MorningFlow. Subscribe at https://t.co/A4zBVUTdec","urls":
["https://t.co/A4zBVUTdec"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"FlowBank","screenName":
"@FlowBank_SA"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Conversation topics","targetingValue":
"Stocks & indices"},{"targetingType":
"Conversation topics","targetingValue":
"Ethereum cryptocurrency"},{"targetingType":
"Conversation topics","targetingValue":
"Bitcoin cryptocurrency"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-13 13:34:07"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:40:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 13:43:07","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:40:23","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:03:25","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Desktop"},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1349015199332900872","tweetText":
"L’assemblage final d’un iPhone ne produit aucun déchet en décharge.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Platforms","targetingValue":
"Desktop"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Languages","targetingValue":
"French"}],"impressionTime":
"2021-06-13 13:30:11"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 13:30:14","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 13:30:17","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 13:30:18","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 13:30:16","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1399868708793823235","tweetText":
"At this year’s EULAR, we’ll share new data from our rheumatology portfolio. Learn more: https://t.co/EbS3gyWYbU","urls":
["https://t.co/EbS3gyWYbU"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"AbbVie","screenName":
"@abbvie"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#inflammation"},{"targetingType":
"Age","targetingValue":
"25 and up"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:49:27","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 06:49:25","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 06:49:27","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 06:49:58","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 06:49:23","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:46:46","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 06:46:49","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 06:46:52","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400774238299111430","tweetText":
"Un essai routier d’un genre particulier: découvre pendant 24h nos modèles ID entièrement électriques. Besoin d'aller au bureau ou faire du sport? Envie de profiter du trajet avec ta famille et des amis? Teste tes modèles ID préférés selon tes envies et ton humeur.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla - Model 3"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:49:19","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 06:49:17","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 06:49:19","engagementType":
"VideoContentPlayback25"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402333291559149569","tweetText":
"Noch nicht für die zweite Ausgabe der IT SECURITY TALKS registriert? Dann jetzt kostenfrei anmelden: https://t.co/0io4RMQDfG\n\n✔ Exklusive Livestreams\n✔ Persönlicher Austausch\n✔ Trends, Visionen &amp; Innovationen\n\nSeien auch Sie dabei - vom 15. bis 17.06.2021!\n\n#itsa365","urls":
["https://t.co/0io4RMQDfG"],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"it-sa Nürnberg","screenName":
"@itsa_Messe"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@securosys"},{"targetingType":
"Keywords","targetingValue":
"#datasecurity"},{"targetingType":
"Keywords","targetingValue":
"it security"},{"targetingType":
"Keywords","targetingValue":
"#cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"information security"},{"targetingType":
"Keywords","targetingValue":
"cybersecurity"},{"targetingType":
"Keywords","targetingValue":
"data security"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:45:32","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 06:45:32","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:48:01","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 06:48:06","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Languages","targetingValue":
"English"}],"impressionTime":
"2021-06-13 06:45:25"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 06:48:57","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401898495267704839","tweetText":
"Rapport de confidentialité. Découvrez comment Safari empêche les traqueurs de vous suivre.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Apple","screenName":
"@Apple"},"matchedTargetingCriteria":
[{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 12:31:31"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:05:39","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:05:41","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:05:41","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 14:05:55","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400083105835274246","tweetText":
"The Yuh app will change the way Swiss people manage their money. Find out how! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 12:31:31"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:05:58","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400725272106831872","tweetText":
"One like no other: Yuh, your new app for all financial questions.😍 Pay, save, invest with just a few clicks. Register now for free and benefit! 🚀 #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Yuh","screenName":
"@yuh_app"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@RevolutApp"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 and up"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 12:31:31"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:04:57","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:04:58","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:05:34","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:05:02","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:04:58","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:05:33","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:04:58","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:04:57","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1401870752656285697","tweetText":
"Auf dem Weg zu Netto-Null: Walter Steinmann (1951) schreibt in seinem ersten Brief an Lisa Hämmerli (1993) von https://t.co/k5BBfexZcX über den internationalen Klimaretter-Hype, Wasserstoff, und die bevorstehende Abstimmung zum CO2-Gesetz. \n#powertage\nhttps://t.co/uokpIKJV3R https://t.co/Xf8fi1JmrH","urls":
["https://t.co/k5BBfexZcX","https://t.co/uokpIKJV3R"],"mediaUrls":
["https://t.co/Xf8fi1JmrH"]},"advertiserInfo":
{"advertiserName":
"Powertage","screenName":
"@Powertage"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@tech_fund"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 17:41:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 18:22:44","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400084548961116165","tweetText":
"L'app Yuh va changer la manière dont les Suisses utilisent leur argent. Découvrez comment! #yuhapp #yuhcandoit #finance #swissquote #postfinance #mastercard","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Swissquote","screenName":
"@Swissquote"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"investment"},{"targetingType":
"Keywords","targetingValue":
"stocks"},{"targetingType":
"Keywords","targetingValue":
"investments"},{"targetingType":
"Interests","targetingValue":
"Financial planning"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Platforms","targetingValue":
"Android"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 and up"}],"impressionTime":
"2021-06-13 17:41:35"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 18:19:24","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1403357888563879937","tweetText":
"Verdiene bis zu 500.000 GTA$ als Bonus, indem du Fahrzeuge in Fahrzeuglieferungen in #GTAOnline beschaffst.\n\nZudem kannst du noch mehr verdienen, indem du Fahrzeughandels-Missionen abschließt und dir so DOPPELTE GTA$ und RP sicherst.\n\nDas Angebot endet am 23. Juni.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Rockstar Games","screenName":
"@RockstarGames"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"level up"},{"targetingType":
"Keywords","targetingValue":
"#nowplaying"},{"targetingType":
"List","targetingValue":
"gtao-018-136-gtaops4xb1pc-activeplayers-eu_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-018-137-gtaops4xb1pc-activeplayers-latamasia_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-029-gtaops4xb1pc-lapsedplayers-latamasia_18ce54ypdu8"},{"targetingType":
"List","targetingValue":
"gtao-010-028-gtaops4xb1pc-lapsedplayers-eu_18ce54ypdu8"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"18 and up"}],"impressionTime":
"2021-06-13 14:00:13"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:00:15","engagementType":
"ChargeableImpression"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-13 14:50:12"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:50:39","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:50:39","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:50:40","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:50:39","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:50:39","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:50:38","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:57:02","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:50:38","engagementType":
"VideoContentPlayback50"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@justinsuntron"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ethereumJoseph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@crypto"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinMarketCap"},{"targetingType":
"Follower look-alikes","targetingValue":
"@brian_armstrong"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BitcoinMagazine"},{"targetingType":
"Follower look-alikes","targetingValue":
"@bgarlinghouse"},{"targetingType":
"Follower look-alikes","targetingValue":
"@BarrySilbert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@aantonop"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitcoin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@ErikVoorhees"},{"targetingType":
"Follower look-alikes","targetingValue":
"@lopp"},{"targetingType":
"Follower look-alikes","targetingValue":
"@balajis"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VentureCoinist"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Cointelegraph"},{"targetingType":
"Follower look-alikes","targetingValue":
"@CoinDesk"},{"targetingType":
"Follower look-alikes","targetingValue":
"@adam3us"},{"targetingType":
"Follower look-alikes","targetingValue":
"@whale_alert"},{"targetingType":
"Follower look-alikes","targetingValue":
"@APompliano"},{"targetingType":
"Follower look-alikes","targetingValue":
"@officialmcafee"},{"targetingType":
"Follower look-alikes","targetingValue":
"@VitalikButerin"},{"targetingType":
"Follower look-alikes","targetingValue":
"@markets"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"}],"impressionTime":
"2021-06-13 14:00:13"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:25:59","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:00:31","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:26:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:00:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:00:36","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:00:31","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:00:28","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:00:30","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:00:20","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:00:38","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Gemini"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 14:37:04"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:55:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:51:24","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:51:23","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:51:23","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 14:51:24","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:51:22","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:51:24","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:51:26","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Gemini"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Age","targetingValue":
"21 to 49"}],"impressionTime":
"2021-06-13 14:05:33"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:25:26","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:25:21","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:25:28","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:25:36","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:25:34","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:25:37","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:25:30","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:25:21","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:25:21","engagementType":
"VideoContentShortFormComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1390580114212245504","tweetText":
"Passez au giga réseau de UPC et savourez l’expérience ! 600 Mbit/s avec UPC TV App pour seulement 39 francs par mois.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"UPC Schweiz","screenName":
"@UPC_Switzerland"},"matchedTargetingCriteria":
[{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 14:39:40"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:50:56","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:50:58","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:50:59","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 14:51:00","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:50:56","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:50:54","engagementType":
"VideoContentPlaybackStart"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400059809282547714","tweetText":
"Les militantes polonaises LGBTQIA+, Elżbieta, Anna et Joanna, accusées d’ « offense aux sentiments religieux », ont été acquittées en première instance. #spreadinghope","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Amnesty Suisse","screenName":
"@Amnesty_Suisse"},"matchedTargetingCriteria":
[{"targetingType":
"Keywords","targetingValue":
"#diversityandinclusion"},{"targetingType":
"Age","targetingValue":
"18 and up"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 14:54:59"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:56:47","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:56:49","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:56:50","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:56:54","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:56:48","engagementType":
"VideoContent1secView"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1400774238299111430","tweetText":
"Un essai routier d’un genre particulier: découvre pendant 24h nos modèles ID entièrement électriques. Besoin d'aller au bureau ou faire du sport? Envie de profiter du trajet avec ta famille et des amis? Teste tes modèles ID préférés selon tes envies et ton humeur.\n\n#vwswitzerland","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Volkswagen Schweiz","screenName":
"@vwschweiz"},"matchedTargetingCriteria":
[{"targetingType":
"Conversation topics","targetingValue":
"Tesla - Model 3"},{"targetingType":
"Conversation topics","targetingValue":
"Tesla Motors"},{"targetingType":
"Conversation topics","targetingValue":
"Sustainability"},{"targetingType":
"Conversation topics","targetingValue":
"Hybrid and electric vehicles"},{"targetingType":
"Keywords","targetingValue":
"technology"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Tesla"},{"targetingType":
"Languages","targetingValue":
"French"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 14:00:13"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:01:04","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:01:14","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:26:05","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:26:06","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:26:06","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 14:01:04","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:26:07","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1402686284091609096","tweetText":
"Our 2021 Impact Report is here! See what our teams have accomplished, what’s ahead, and the partners we’ve joined forces with along the way.","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Comcast","screenName":
"@comcast"},"matchedTargetingCriteria":
[{"targetingType":
"List","targetingValue":
"Negative IE Engagers_TWITTER_ID_INCLUDED"}],"impressionTime":
"2021-06-13 14:43:09"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:50:52","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:50:52","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:50:52","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:50:52","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:50:52","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:57:06","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:50:58","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:57:09","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:57:09","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:57:19","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:57:07","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:57:09","engagementType":
"VideoContentPlaybackComplete"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Gemini"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"Age","targetingValue":
"21 to 49"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Locations","targetingValue":
"Switzerland"}],"impressionTime":
"2021-06-13 14:18:15"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:18:20","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:18:50","engagementType":
"VideoContentShortFormComplete"},{"engagementTime":
"2021-06-13 14:18:44","engagementType":
"VideoContentPlayback75"},{"engagementTime":
"2021-06-13 14:18:20","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:29:25","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:18:49","engagementType":
"VideoContentPlayback95"},{"engagementTime":
"2021-06-13 14:18:50","engagementType":
"VideoContentPlaybackComplete"},{"engagementTime":
"2021-06-13 14:37:05","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:29:19","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:18:24","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:29:22","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:19:06","engagementType":
"VideoSession"}]},{"impressionAttributes":
{"deviceInfo":
{"osType":
"Android","deviceId":
"5PUake33TotLdJaLdfujR7VJtgQ5uyQU2Hb7OIU8sCw="},"displayLocation":
"TimelineHome","promotedTweetInfo":
{"tweetId":
"1372390240556613633","tweetText":
"Buying Bitcoin is fast, easy, and secure on Binance, the world's largest crypto exchange.\n\nGet the App 📲","urls":
[],"mediaUrls":
[]},"advertiserInfo":
{"advertiserName":
"Binance","screenName":
"@binance"},"matchedTargetingCriteria":
[{"targetingType":
"Follower look-alikes","targetingValue":
"@coinbase"},{"targetingType":
"Follower look-alikes","targetingValue":
"@krakenfx"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Gemini"},{"targetingType":
"Follower look-alikes","targetingValue":
"@Bitstamp"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-1436799971-IOS"},{"targetingType":
"App Activity","targetingValue":
"RE_ENGAGE-com.binance.dev-ANDROID"},{"targetingType":
"App Activity","targetingValue":
"INSTALL-1436799971-IOS"},{"targetingType":
"Locations","targetingValue":
"Switzerland"},{"targetingType":
"Gender","targetingValue":
"Men"},{"targetingType":
"OS versions","targetingValue":
"Android Lollipop and above"},{"targetingType":
"Languages","targetingValue":
"English"},{"targetingType":
"Age","targetingValue":
"21 to 49"}],"impressionTime":
"2021-06-13 14:27:31"},"engagementAttributes":
[{"engagementTime":
"2021-06-13 14:27:40","engagementType":
"VideoContentPlayback50"},{"engagementTime":
"2021-06-13 14:28:01","engagementType":
"VideoSession"},{"engagementTime":
"2021-06-13 14:27:38","engagementType":
"VideoContentMrcView"},{"engagementTime":
"2021-06-13 14:28:00","engagementType":
"VideoContentViewThreshold"},{"engagementTime":
"2021-06-13 14:28:00","engagementType":
"VideoContentViewV2"},{"engagementTime":
"2021-06-13 14:27:40","engagementType":
"VideoContent1secView"},{"engagementTime":
"2021-06-13 14:27:33","engagementType":
"VideoContentPlaybackStart"},{"engagementTime":
"2021-06-13 14:27:37","engagementType":
"VideoContentPlayback25"},{"engagementTime":
"2021-06-13 14:27:40","engagementType":
"VideoContent6secView"}]}]}}}}]
