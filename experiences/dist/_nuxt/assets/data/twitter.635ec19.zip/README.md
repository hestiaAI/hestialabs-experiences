This archive contains a subset of Twitter files accessible through the data download tool:
- data/personalization.js
- data/ad-engagements.js
- data/ad-impressions.js
