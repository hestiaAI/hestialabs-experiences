SELECT * FROM InstagramPhoto;
