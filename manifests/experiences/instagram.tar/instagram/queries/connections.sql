SELECT * FROM InstagramConnection;
