SELECT * FROM InstagramComment;
