SELECT * FROM InstagramLike;
